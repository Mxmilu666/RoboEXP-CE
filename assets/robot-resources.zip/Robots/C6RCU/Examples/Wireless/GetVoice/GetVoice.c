#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayStr.h>
#include <GetComVoice.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    C6RCU_Init();
    unsigned char var0 = 0;
    unsigned char var1 = 0;
    SetDisplayStr(0, 0, "�ֻ���������ʶ��", YELLOW, BLACK);
    while (1)
    {
        var0 = GetComVoice("Hello");
        var1 = GetComVoice("���");
        SetDisplayVar(1, var0, YELLOW, BLACK);
        SetDisplayVar(2, var1, YELLOW, BLACK);
        if ( var0==1||var1==1 )
        {
            SetWaitForTime(0.5);
        }
    }
    while(1);
}

