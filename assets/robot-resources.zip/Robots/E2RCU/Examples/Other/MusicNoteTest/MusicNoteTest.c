#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <SetMusicNote.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Music", WHITE, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        SetMusicNote(_P1_, 6, 4, 0, 0);
        SetMusicNote(_P1_, 1, 4, 1, 0);
        SetMusicNote(_P1_, 3, 4, 1, 0);
        SetMusicNote(_P1_, 1, 4, 1, 0);
        SetMusicNote(_P1_, 2, 6, 1, 0);
        SetMusicNote(_P1_, 1, 4, 1, 0);
        SetMusicNote(_P1_, 7, 4, 0, 0);
        SetMusicNote(_P1_, 3, 6, 1, 0);
        SetMusicNote(_P1_, 2, 6, 1, 0);
        SetMusicNote(_P1_, 6, 5, 0, 0);
        SetMusicNote(_P1_, 1, 4, 1, 0);
        SetMusicNote(_P1_, 3, 4, 1, 0);
        SetMusicNote(_P1_, 5, 4, 1, 0);
        SetMusicNote(_P1_, 5, 4, 1, 0);
        SetMusicNote(_P1_, 6, 6, 1, 0);
        SetMusicNote(_P1_, 5, 4, 1, 0);
        SetMusicNote(_P1_, 4, 4, 1, 0);
        SetMusicNote(_P1_, 3, 5, 1, 0);
        SetMusicNote(_P1_, 4, 6, 1, 0);
        SetMusicNote(_P1_, 5, 6, 1, 0);
        SetMusicNote(_P1_, 7, 4, 1, 0);
        SetMusicNote(_P1_, 6, 4, 1, 0);
        SetMusicNote(_P1_, 3, 4, 1, 0);
        SetMusicNote(_P1_, 3, 4, 1, 0);
        SetMusicNote(_P1_, 7, 6, 0, 0);
        SetMusicNote(_P1_, 6, 4, 0, 0);
        SetMusicNote(_P1_, 3, 4, 1, 0);
        SetMusicNote(_P1_, 2, 4, 1, 0);
        SetMusicNote(_P1_, 4, 6, 1, 0);
        SetMusicNote(_P1_, 4, 4, 1, 0);
        SetMusicNote(_P1_, 0, 4, 1, 0);
        SetMusicNote(_P1_, 5, 4, 1, 0);
        SetMusicNote(_P1_, 4, 4, 1, 0);
        SetMusicNote(_P1_, 3, 6, 1, 0);
        SetMusicNote(_P1_, 2, 4, 1, 0);
        SetMusicNote(_P1_, 1, 4, 1, 0);
        SetMusicNote(_P1_, 3, 6, 1, 0);
        SetMusicNote(_P1_, 2, 6, 1, 0);
        SetMusicNote(_P1_, 6, 5, 0, 0);
        SetMusicNote(_P1_, 6, 4, 0, 0);
        SetWaitForTime(1);
    }
    while(1);
}

