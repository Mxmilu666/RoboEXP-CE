#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <GetAccWireless.h>
#include <SetLCD3Char.h>

// define global var
int wireless_x = 0;
int wireless_y = 0;
int wireless_z = 0;

int main(void)
{
    X2RCU_Init();
    SetLCDBack(1);
    while (1)
    {
        GetAccWireless(_WIRELESS_1_, "1234567");
        SetLCD3Char(0, 0, wireless_x, YELLOW, BLACK);
        SetLCD3Char(0, 16, wireless_y, YELLOW, BLACK);
        SetLCD3Char(0, 32, wireless_z, YELLOW, BLACK);
    }
    return 1;
}

