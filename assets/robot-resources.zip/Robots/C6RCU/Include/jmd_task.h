//***************************(C) COPYRIGHT 2019 LXW ******************************
// File Name   	: jmd_task.h 
// Author       : LXW
// Version      : V0.0
// Date         : 2019/4/25
// Target       : E6RCU
// Compiler     : GCCARM
// Description  : 
//*******************************************************************************
//
//*******************************************************************************
#ifndef _JMD_TASK_H_
#define _JMD_TASK_H_
//Define to prevent recursive inclusion -------------------------------------


//Includes -��Ҫ��ͷ�ļ�-----------------------------------------------------

//#include "jmdram.h"
#include "jdy16.h"

void os_com_task(void);//����ͨ������
void os_com_task(void)//����ͨ������
{
	BlueTH_Init(115200);
	while(1);
}


#endif
