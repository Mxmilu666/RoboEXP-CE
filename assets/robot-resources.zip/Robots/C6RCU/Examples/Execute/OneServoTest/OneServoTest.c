#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetOneServo.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E3RCU_Init();
    long var0 = 0;
    SetLCDBack(1);
    while (1)
    {
        SetOneServo(_P1_, 1, 90, 0);
        if ( var0<90 )
        {
            var0=180;
        }
        else
        {
            var0=0;
        }
        SetDisplayVar(1, var0, YELLOW, BLACK);
        SetWaitForTime(1);
    }
    while(1);
}

