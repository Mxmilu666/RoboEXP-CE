#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetScanCamera.h>
#include <SetDisplayVar.h>

int main(void)
{
    E3RCU_Init();
    long var0 = 0;
    while (1)
    {
        var0 = GetScanCamera();
        if ( var0!=999 )
        {
            SetDisplayVar(1, var0, YELLOW, BLACK);
        }
    }
    while(1);
}

