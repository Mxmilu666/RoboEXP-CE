#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetLightSensor.h>
#include <SetRGB.h>
#include <SetWaitForTime.h>

int main(void)
{
   C1RCU_Init();
    unsigned int var0 = 0;
    while (1)
    {
        var0 = GetLightSensor(_A1_);
        if ( var0<=2000 )
        {
            SetRGB(0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000);
        }
        else
        {
            SetRGB(0, 0, 0, 0, 0);
        }
        SetWaitForTime(0.1);
    }
    while(1);
}

