#include "HardwareInfo.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetInfrared.h>
#include <SetDisplayVar.h>

int main(void)
{
    E3RCU_Init();
    int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Infrared", YELLOW, BLACK);
    while (1)
    {
        var0 = GetInfrared(_P1_);
        SetDisplayVar(3, var0, YELLOW, BLACK);
    }
    while(1);
}

