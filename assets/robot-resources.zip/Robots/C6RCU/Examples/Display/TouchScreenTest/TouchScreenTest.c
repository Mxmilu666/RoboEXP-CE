#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <GetTouchScreenX.h>
#include <GetTouchScreenY.h>
#include <SetLCDDot.h>

int main(void)
{
    C6RCU_Init();
    unsigned int var1 = 0;
    unsigned int var2 = 0;
    SetDisplayString(1, "������Ļ", YELLOW, BLACK);
    while (1)
    {
        var1 = GetTouchScreenX();
        var2 = GetTouchScreenY();
        SetLCDDot(var1, var2, YELLOW);
    }
    while(1);
}

