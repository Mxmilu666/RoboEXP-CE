#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetInMic.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    int var0 = 0;
    while (1)
    {
        var0 = GetInMic();
        SetDisplayVar(1, var0, YELLOW, BLACK);
    }
    while(1);
}

