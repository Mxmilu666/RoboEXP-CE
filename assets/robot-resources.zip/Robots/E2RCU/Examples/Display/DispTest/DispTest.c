#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>

int main(void)
{
    E2RCU_Init();
    SetDisplayString(2, "Hello!", YELLOW, BLACK);
    while(1);
}

