#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetFontSize.h>

int main(void)
{
    C6RCU_Init();
    SetDisplayString(1, "Hello!", YELLOW, BLACK);
    SetDisplayString(2, "���", YELLOW, BLACK);
    SetFontSize(1);
    SetDisplayString(5, "Hello!", YELLOW, BLACK);
    SetDisplayString(6, "���", YELLOW, BLACK);
    while(1);
}

