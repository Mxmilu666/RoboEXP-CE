#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetMotorServo.h>
#include <SetWaitForTime.h>
#include <SetInBeep.h>

int main(void)
{
    E2RCU_Init();
    SetMotorServo(_M1_, 50, 270);
    SetWaitForTime(0.8);
    SetInBeep(ON);
    SetMotorServo(_M1_, -50, 270);
    SetWaitForTime(0.8);
    SetInBeep(OFF);
    while(1);
}

