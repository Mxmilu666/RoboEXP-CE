#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <GetWifiCamRockCtrl.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    long var1 = 0;
    long var0 = 0;
    long var2 = 0;
    long var3 = 0;
    long var4 = 0;
    SetDisplayString(1, "����ͷҡ��ʶ��", YELLOW, BLACK);
    SetDisplayString(2, "��ҡ��X��", YELLOW, BLACK);
    SetDisplayString(3, "��ҡ��Y��", YELLOW, BLACK);
    SetDisplayString(4, "��ҡ��X��", YELLOW, BLACK);
    SetDisplayString(5, "��ҡ��Y��", YELLOW, BLACK);
    while (1)
    {
        var0 = GetWifiCamRockCtrl(0, 0);
        var1 = GetWifiCamRockCtrl(0, 1);
        var2 = GetWifiCamRockCtrl(1, 0);
        var3 = GetWifiCamRockCtrl(1, 1);
        SetDisplayVar(2, var0, YELLOW, BLACK);
        SetDisplayVar(3, var1, YELLOW, BLACK);
        SetDisplayVar(4, var2, YELLOW, BLACK);
        SetDisplayVar(5, var3, YELLOW, BLACK);
    }
    while(1);
}

