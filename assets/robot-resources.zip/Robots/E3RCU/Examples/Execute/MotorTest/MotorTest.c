#include "HardwareInfo.c"
#include <SetMotor.h>
#include <SetWaitForTime.h>

int main(void)
{
    E3RCU_Init();
    while (1)
    {
        SetMotor(_M1_, 100);
        SetMotor(_M2_, 100);
        SetWaitForTime(1);
        SetMotor(_M1_, -100);
        SetMotor(_M2_, -100);
        SetWaitForTime(1);
    }
    while(1);
}

