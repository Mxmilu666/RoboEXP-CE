#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <GetPS2LeftRocker.h>
#include <GetPS2RightRocker.h>
#include <SetLCD3Char.h>

int main(void)
{
    X1RCU_Init();
    unsigned int Rocker_left = 0;
    unsigned int Rocker_Right = 0;
    unsigned char Rocker_Left_changnal1 = 0;
    unsigned char Rocker_Left_changnal2 = 0;
    unsigned char Rocker_Right_changnal1 = 0;
    unsigned char Rocker_Right_changnal2 = 0;
    SetLCDBack(1);
    while (1)
    {
        Rocker_left = GetPS2LeftRocker(_PS2_1_);
        Rocker_Right = GetPS2RightRocker(_PS2_1_);
        Rocker_Left_changnal1=Rocker_left/256;
        Rocker_Left_changnal2=Rocker_left%256;
        Rocker_Right_changnal1=Rocker_Right/256;
        Rocker_Right_changnal2=Rocker_Right%256;
        SetLCD3Char(0, 0, Rocker_Left_changnal1);
        SetLCD3Char(64, 0, Rocker_Left_changnal2);
        SetLCD3Char(0, 2, Rocker_Right_changnal1);
        SetLCD3Char(64, 2, Rocker_Right_changnal2);
    }
    return 1;
}

