#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetBluetoothControlData.h>
#include <SetDisplayVar.h>
#include <SetInBeep.h>

int main(void)
{
    C6RCU_Init();
    long var1 = 0;
    while (1)
    {
        var1 = GetBluetoothControlData();
        SetDisplayVar(1, var1, YELLOW, BLACK);
        if ( var1==1 )
        {
            SetInBeep(ON);
        }
        else
        {
            SetInBeep(OFF);
        }
    }
    while(1);
}

