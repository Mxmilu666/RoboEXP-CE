#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetWaitForTime.h>
#include <SetLCDBack.h>
#include <GetCalendar.h>
#include <SetDisplayVar.h>

int main(void)
{
    E2RCU_Init();
    unsigned char sec = 0;
    unsigned char min = 0;
    unsigned char hour = 0;
    unsigned char date = 0;
    unsigned char month = 0;
    unsigned char day = 0;
    unsigned char year = 0;
    unsigned char temp = 0;
    unsigned char week = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Year:", YELLOW, BLACK);
    SetDisplayString(3, "Month:", YELLOW, BLACK);
    SetDisplayString(4, "Date:", YELLOW, BLACK);
    SetDisplayString(5, "Hour:", YELLOW, BLACK);
    SetDisplayString(6, "Min:", YELLOW, BLACK);
    SetDisplayString(7, "Sec:", YELLOW, BLACK);
    SetDisplayString(8, "Temp:", YELLOW, BLACK);
    SetWaitForTime(1);
    SetLCDBack(ON);
    while (1)
    {
        year = GetCalendar(_P1_, 30);
        SetDisplayVar(2, year, YELLOW, BLACK);
        month = GetCalendar(_P1_, 31);
        SetDisplayVar(3, month, YELLOW, BLACK);
        date = GetCalendar(_P1_, 32);
        SetDisplayVar(4, date, YELLOW, BLACK);
        date = GetCalendar(_P1_, 33);
        SetDisplayVar(5, hour, YELLOW, BLACK);
        date = GetCalendar(_P1_, 34);
        SetDisplayVar(6, min, YELLOW, BLACK);
        date = GetCalendar(_P1_, 35);
        SetDisplayVar(7, sec, YELLOW, BLACK);
        SetWaitForTime(1);
        date = GetCalendar(_P1_, 37);
        SetDisplayVar(8, temp, YELLOW, BLACK);
        SetWaitForTime(1);
    }
    while(1);
}

