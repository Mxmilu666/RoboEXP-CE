#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetFontSize.h>
#include <SetDisplayString.h>
#include <SetWifiUdpMode.h>
#include <SetWifiData.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E3RCU_Init();
    unsigned int var0 = 0;
    SetLCDBack(ON);
    SetFontSize(1);
    SetDisplayString(1, "WIFI Send:", YELLOW, BLACK);
    SetWifiUdpMode("255.255.255.255", 8080, 8080);
    while (1)
    {
        SetWifiData(var0);
        SetDisplayVar(2, var0, YELLOW, BLACK);
        if ( var0<255 )
        {
            var0++;
        }
        else
        {
            var0=0;
        }
        SetWaitForTime(1);
    }
    while(1);
}

