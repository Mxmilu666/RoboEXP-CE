#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetRemoteControllerRocker.h>
#include <SetDisplayVar.h>

int main(void)
{
    E2RCU_Init();
    int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "Remote Controller", YELLOW, BLACK);
    SetDisplayString(2, "Rocker", YELLOW, BLACK);
    SetDisplayString(4, "Left  X:", YELLOW, BLACK);
    SetDisplayString(5, "Left  Y:", YELLOW, BLACK);
    SetDisplayString(7, "Right X:", YELLOW, BLACK);
    SetDisplayString(8, "Right Y:", YELLOW, BLACK);
    while (1)
    {
        var0 = GetRemoteControllerRocker(0, 0);
        SetDisplayVar(4, var0, YELLOW, BLACK);
        var0 = GetRemoteControllerRocker(0, 1);
        SetDisplayVar(5, var0, YELLOW, BLACK);
        var0 = GetRemoteControllerRocker(1, 0);
        SetDisplayVar(7, var0, YELLOW, BLACK);
        var0 = GetRemoteControllerRocker(1, 1);
        SetDisplayVar(8, var0, YELLOW, BLACK);
    }
    return 1;
}

