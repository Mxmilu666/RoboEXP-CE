#ifndef _PINFORMAT_
#define _PINFORMAT_

const u32 portarray[6]={0,0x40010800,0x40010c00,0x40011000,0x40011400,0x40011800};
const u8  E2PORT[9][3]={{0,0,0},{5,5,1},{5,2,1},{5,5,1},{5,5,3},{5,5,3},{5,2,3},{5,5,3},{2,2,3}};
const u8  E2PIN[9][3]={{0,0,0},{9,8,7},{7,2,6},{4,3,5},{2,1,3},{11,10,4},{0,9,2},{13,12,5},{8,7,1}};

#define _P1_ 1
#define _P2_ 2
#define _P3_ 3
#define _P4_ 4
#define _P5_ 5
#define _P6_ 6
#define _P7_ 7
#define _P8_ 8

#define _M1_ 1
#define _M2_ 2
#define _M3_ 3
#define _M4_ 4

#endif
