#include "HardwareInfo.c"
#include "JMLib.c"
#include <Set3CLed.h>
#include <SetWaitForTime.h>

int main(void)
{
    C6RCU_Init();
    while (1)
    {
        Set3CLed(_P1_, RED);
        SetWaitForTime(1);
        Set3CLed(_P1_, OFF);
        SetWaitForTime(1);
        Set3CLed(_P1_, BLUE);
        SetWaitForTime(1);
        Set3CLed(_P1_, OFF);
        SetWaitForTime(1);
        Set3CLed(_P1_, GREEN);
        SetWaitForTime(1);
        Set3CLed(_P1_, OFF);
        SetWaitForTime(1);
    }
    while(1);
}

