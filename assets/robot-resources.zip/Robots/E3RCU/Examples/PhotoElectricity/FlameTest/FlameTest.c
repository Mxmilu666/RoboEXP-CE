#include "HardwareInfo.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetRemoIR.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E3RCU_Init();
    int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Flame", YELLOW, BLACK);
    while (1)
    {
        var0 = GetRemoIR(_P1_);
        SetDisplayVar(3, var0, YELLOW, BLACK);
        SetWaitForTime(0.1);
    }
    while(1);
}

