#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetGSensor.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    int x = 0;
    int y = 0;
    int z = 0;
    unsigned char P2 = 2;
    SetLCDBack(OFF);
    SetDisplayString(1, "P1: Gsensor", YELLOW, BLACK);
    SetDisplayString(2, "          X:", YELLOW, BLACK);
    SetDisplayString(3, "          Y:", YELLOW, BLACK);
    SetDisplayString(4, "          Z:", YELLOW, BLACK);
    while (1)
    {
        x = GetGSensor(_P1_, 1);
        SetDisplayVar(2, x, YELLOW, BLACK);
        y = GetGSensor(_P1_, 2);
        SetDisplayVar(3, y, YELLOW, BLACK);
        z = GetGSensor(_P1_, 3);
        SetDisplayVar(4, z, YELLOW, BLACK);
        SetWaitForTime(0.2);
    }
    while(1);
}

