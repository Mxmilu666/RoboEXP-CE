#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetInBeep.h>
#include <SetWaitForTime.h>

int main(void)
{
    E6RCU_Init();
    SetInBeep(ON);
    SetWaitForTime(1);
    SetInBeep(OFF);
    SetWaitForTime(1);
    SetInBeep(ON);
    SetWaitForTime(0.5);
    SetInBeep(OFF);
    while(1);
}

