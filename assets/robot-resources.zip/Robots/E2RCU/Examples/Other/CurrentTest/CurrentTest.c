#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <GetCurrent.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    unsigned int var0 = 0;
    int dec = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Current", YELLOW, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        var0 = GetCurrent(_P1_);
        SetDisplayVar(3, var0, YELLOW, BLACK);
        SetWaitForTime(0.2);
    }
    while(1);
}

