#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetPhoto.h>
#include <SetDisplayVar.h>

int main(void)
{
    E2RCU_Init();
    unsigned int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Photo", YELLOW, BLACK);
    while (1)
    {
        var0 = GetPhoto(_P1_);
        SetDisplayVar(3, var0, YELLOW, BLACK);
    }
    while(1);
}

