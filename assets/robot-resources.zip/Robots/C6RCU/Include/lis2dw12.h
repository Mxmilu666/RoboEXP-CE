#ifndef _LIS2DW12_H_
#define _LIS2DW12_H_
#include "I2C_Soft.h"
#include "pinformat.h"
#include "DTHSensor.h"
////////////////////2024-05-22///////��б������////////////////////////////////////////////////
///��б������  start
#define _LIS2DW12_ADDR_W_1                    0x32U //�豸��ַ

#define LIS2DW12_OUT_T_L                     0x0DU
#define LIS2DW12_OUT_T_H                     0x0EU
#define LIS2DW12_WHO_AM_I                    0x0FU
#define LIS2DW12_CTRL1                       0x20U

#define LIS2DW12_OUT_X_L                     0x28U
#define LIS2DW12_OUT_X_H                     0x29U
#define LIS2DW12_OUT_Y_L                     0x2AU
#define LIS2DW12_OUT_Y_H                     0x2BU
#define LIS2DW12_OUT_Z_L                     0x2CU
#define LIS2DW12_OUT_Z_H                     0x2DU

#define LIS2DW12_OUT_T                       0x26U
#define LIS2DW12_STATUS                      0x27U

//LIS2DW12д
int IIC_WrDat_LIS2DW12(uint8_t IIC_Add, uint8_t IIC_Reg, uint8_t IIC_Data, Soft_I2C_Typedef *iic_typedef)
{
	Soft_I2C_Start(iic_typedef);
	Soft_I2C_Write(iic_typedef,IIC_Add & 0xfe);//��д����
	Soft_I2C_Write(iic_typedef,IIC_Reg);
	Soft_I2C_Write(iic_typedef,IIC_Data);
	Soft_I2C_Stop(iic_typedef);
	return 0;
}

//LIS2DW12��
int IIC_Read_LIS2DW12(uint8_t IIC_Add, uint8_t IIC_Reg, Soft_I2C_Typedef *iic_typedef)
{
	int ret;
	Soft_I2C_Start(iic_typedef);
	Soft_I2C_Write(iic_typedef,IIC_Add & 0xfe);
	Soft_I2C_Write(iic_typedef,IIC_Reg);
	
	Soft_I2C_Start(iic_typedef);
	Soft_I2C_Write(iic_typedef,IIC_Add | 0x01);
	ret = Soft_I2C_Read(iic_typedef,1);
	Soft_I2C_Stop(iic_typedef);
	
	return ret;
}

//LIS2DW12��2���Ĵ���
int IIC_Read2_LIS2DW12(uint8_t IIC_Add, uint8_t IIC_Reg, Soft_I2C_Typedef *iic_typedef)
{
	int ret;
	Soft_I2C_Start(iic_typedef);
	Soft_I2C_Write(iic_typedef,IIC_Add & 0xfe);
	Soft_I2C_Write(iic_typedef,IIC_Reg);
	
	Soft_I2C_Start(iic_typedef);
	Soft_I2C_Write(iic_typedef,IIC_Add | 0x01);
	ret = Soft_I2C_Read(iic_typedef,0);
	ret = (Soft_I2C_Read(iic_typedef,1)<<8)|ret;
	Soft_I2C_Stop(iic_typedef);
	
	return ret;
}

//���üĴ���
int Set_Reg_LIS2DW12(uint8_t add, uint8_t reg, uint8_t dat, Soft_I2C_Typedef *iic_typedef)
{
	int ret_succ = -1;
	uint8_t i = 5;		//ʧ��֮���ԵĴ���
	do{
		if(0 == IIC_WrDat_LIS2DW12(add, reg, dat, iic_typedef))
		{
			ret_succ = 0;		//���óɹ�
			break;
		}
		else
		{
			i--;				//��ȡʧ�ܣ��ٴγ���
		}
	}while(i>0);
	
	return ret_succ;
}

//��ȡ�Ĵ���
int Get_Reg_LIS2DW12(uint8_t add, uint8_t reg, Soft_I2C_Typedef *iic_typedef)
{
	uint8_t i = 5;
	int ret_get = -1;
	
	do{
		ret_get = IIC_Read_LIS2DW12(add, reg, iic_typedef);
		if(-1 != ret_get)
		{
			break;				//��ȡ���ݳɹ�
		}
		else
		{
			i--;				//��ȡʧ�ܣ��ٴγ���
		}
	}while(i>0);
	
	return ret_get;	
}

//��ȡ����˭���޴�����ʱ����255
int Get_WHO_AM_I_LIS2DW12(Soft_I2C_Typedef *iic_typedef)
{
	return Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_WHO_AM_I, iic_typedef);	
}

//��ȡ״̬�Ĵ���
int Get_Status_LIS2DW12(Soft_I2C_Typedef *iic_typedef)
{
	return Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_STATUS, iic_typedef);	
}

float Get_Temp_1_LIS2DW12(Soft_I2C_Typedef *iic_typedef)
{
	short temp_reg = (Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_OUT_T_H, iic_typedef)<<8)|Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_OUT_T_L, iic_typedef);
	float temp_cal = 0.0f;
	
	temp_cal = 25.0+temp_reg/16.0/16.0;
	
	return temp_cal;
}

signed char Get_Temp_2_LIS2DW12(Soft_I2C_Typedef *iic_typedef)
{
	return (25+(Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_OUT_T, iic_typedef)));
}

int32_t Get_X_LIS2DW(Soft_I2C_Typedef *iic_typedef)
{
	return -((Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_OUT_Y_H, iic_typedef)<<8)|Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_OUT_Y_L, iic_typedef));
}

int32_t Get_Y_LIS2DW(Soft_I2C_Typedef *iic_typedef)
{
	return -((Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_OUT_X_H, iic_typedef)<<8)|Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_OUT_X_L, iic_typedef));
}

int32_t Get_Z_LIS2DW(Soft_I2C_Typedef *iic_typedef)
{
	return -((Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_OUT_Z_H, iic_typedef)<<8)|Get_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_OUT_Z_L, iic_typedef));
}


///��б������  ������ٶ�  ����ֵ��λ��mg  
int16_t Get_TiltAxis(uint8_t port,uint8_t axis) 
{
	
	// uint32_t port1=0;//I2C_SCL
	// uint32_t port2=0;//I2C_SDA
	// uint8_t bit1,bit2;

    uint32_t port1 = portarray[RcuPORT[port][0]];//EchoPin
	uint32_t port2 = portarray[RcuPORT[port][1]];//TrigPin
	uint8_t bit1=RcuPIN[port][0];//EchoPin
	uint8_t bit2=RcuPIN[port][1];//TrigPin

	int16_t  acc_data=0;
	//printf("Get_TiltAxis init\n ");
	Soft_I2C_Typedef iic_typedef;
	Soft_I2C_BspInit(port2,bit2,//SDA
                   port1,bit1,//SCL
				   &iic_typedef);
	delay_iic=IIC_SPEED_100K;
	
	if(!Get_Status_LIS2DW12(&iic_typedef))//�ε��������󣬳�ʼ��1��
	{

		//2g 14bit
		//CTRL1 (20h) 0x56 01010110
		//bit 7-4: 0101 High-Performance / Low-Power mode 100 Hz
		//bit 3-2: 01 High-Performance Mode (14-bit resolution)
		//bit 1-0: 10 Low-Power Mode 3 (14-bit resolution)
		Delay1ms(20);
		Set_Reg_LIS2DW12(_LIS2DW12_ADDR_W_1, LIS2DW12_CTRL1, 0x56, &iic_typedef);//��ʼ��  LIS2DW12_ADDR_W_1 ��LIS2DW12_CTRL1
		Delay1ms(5);
		//printf("Tilt init\n ");
		
	}
	if(axis==1)
	{
		acc_data=Get_X_LIS2DW(&iic_typedef);
	}
	else if(axis==2)
	{
		acc_data=Get_Y_LIS2DW(&iic_typedef);
	}
	else if(axis==3)
	{
		acc_data=Get_Z_LIS2DW(&iic_typedef);
	}
	else 
	{
		acc_data=0;
	}
	acc_data=(acc_data*0.224)/4; //�������ٶ� = acc_data��ԭʼ����LSB�� /4����2g�� *0.224(������ ��λmg/LSB)
	delay_iic=IIC_SPEED_DEFAULT;
	//ESP_LOGI(M5_TAG,"Tiltaxis = %d",acc_data);
	//printf("Tiltaxis = %d\n",acc_data);
	return acc_data;//mg

}

int16_t  acc_data_offset = 800;
uint8_t Get_RcuAttitude(uint8_t port,uint8_t axis) 
{
	
	int16_t acc_dataX = Get_TiltAxis(port,1);
	int16_t acc_dataY = Get_TiltAxis(port,2);
	int16_t acc_dataZ = Get_TiltAxis(port,3);
	static uint8_t shakex = 0, shakey = 0, shakez = 0;
	uint16_t state = 0;
	switch (axis)
	{
		case 1://��
			if( (acc_dataZ > acc_data_offset) && (acc_dataX < 100) && (acc_dataY < 100)) state = 1;
			break;
		case 2://��
			if( (acc_dataZ < -acc_data_offset)&& (acc_dataX < 100) && (acc_dataY < 100)) state = 1;
			break;
		case 3://��
			if( (acc_dataX > acc_data_offset)&& (acc_dataY < 100) && (acc_dataZ < 100))state = 1;
			break;
		case 4://��
			if( (acc_dataX < -acc_data_offset)&& (acc_dataY < 100) && (acc_dataZ < 100))state = 1;
			break;
		case 5://ǰ
			if( (acc_dataY > acc_data_offset)&& (acc_dataX < 100) && (acc_dataZ < 100))state = 1;
		break;
		case 6://��
			if( (acc_dataY < -acc_data_offset)&& (acc_dataX < 100) && (acc_dataZ < 100))state = 1;
		break;
		case 7://ҡ��
			if( (acc_dataX > acc_data_offset))shakex = 1;
			else if(shakex == 1 && (acc_dataX < -acc_data_offset)){shakex = 0;state = 1;}
			if( (acc_dataY > acc_data_offset))shakey = 1;
			else if(shakey == 1 && (acc_dataY < -acc_data_offset)){shakey = 0;state = 1;}
			if( (acc_dataZ > acc_data_offset))shakez = 1;
			else if(shakez == 1 && (acc_dataZ < -acc_data_offset)){shakez = 0;state = 1;}
		break;
		default:
			break;
	}
	return state;
}

#endif

