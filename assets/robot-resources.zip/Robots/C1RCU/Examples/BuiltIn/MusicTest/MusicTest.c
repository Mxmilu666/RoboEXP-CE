#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetNote.h>
#include <SetWaitForTime.h>

int main(void)
{
   C1RCU_Init();
    SetNote(1);
    SetWaitForTime(0.2);
    SetNote(2);
    SetWaitForTime(0.2);
    SetNote(3);
    SetWaitForTime(0.2);
    SetNote(4);
    SetWaitForTime(0.2);
    SetNote(5);
    SetWaitForTime(0.2);
    SetNote(6);
    SetWaitForTime(0.2);
    SetNote(7);
    SetWaitForTime(0.2);
    SetNote(0);
    while (1)
    {
    }
    while(1);
}

