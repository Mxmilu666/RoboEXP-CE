#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetFontSize.h>
#include <GetWifiVoice.h>
#include <SetWifiVoiceString.h>
#include <SetDisplayVar.h>
#include <SetInBeep.h>
#include <SetWaitForTime.h>

int main(void)
{
    E3RCU_Init();
    int var0 = 0;
    SetFontSize(1);
    while (1)
    {
        var0 = GetWifiVoice("Hello");
        SetWifiVoiceString(1, YELLOW, BLACK);
        SetDisplayVar(2, var0, YELLOW, BLACK);
        if ( var0==1 )
        {
            SetInBeep(ON);
            SetWaitForTime(0.3);
            SetInBeep(OFF);
            SetWaitForTime(1);
        }
    }
    while(1);
}

