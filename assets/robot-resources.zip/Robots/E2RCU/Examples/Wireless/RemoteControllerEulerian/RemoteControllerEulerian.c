#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetRemoteControllerEulerian.h>
#include <SetDisplayVar.h>

int main(void)
{
    E2RCU_Init();
    int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "Remote Controller", YELLOW, BLACK);
    SetDisplayString(2, "Eulerian", YELLOW, BLACK);
    SetDisplayString(4, "Roll:", YELLOW, BLACK);
    SetDisplayString(5, "Pitch:", YELLOW, BLACK);
    SetDisplayString(6, "Yaw:", YELLOW, BLACK);
    while (1)
    {
        var0 = GetRemoteControllerEulerian(1);
        SetDisplayVar(4, var0, YELLOW, BLACK);
        var0 = GetRemoteControllerEulerian(2);
        SetDisplayVar(5, var0, YELLOW, BLACK);
        var0 = GetRemoteControllerEulerian(3);
        SetDisplayVar(6, var0, YELLOW, BLACK);
    }
    return 1;
}

