#ifndef _WS2812B_H_
#define _WS2812B_H_

void WS2812B_Init(void);
void WS2812B_Reset(void);
void WS2812B_Send(uint32_t color);
void rcu_WS2812B_disp(uint32_t c1,uint32_t c2,uint32_t c3);
void WS2812B_Colour(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin,uint8_t color);

#endif

