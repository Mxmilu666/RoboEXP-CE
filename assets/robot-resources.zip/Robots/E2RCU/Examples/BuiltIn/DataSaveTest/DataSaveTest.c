#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetData.h>
#include <GetData.h>
#include <SetDisplayVar.h>

int main(void)
{
    E2RCU_Init();
    unsigned int var0 = 0;
    SetData(1, 55);
    var0 = GetData(1);
    SetDisplayVar(1, var0, YELLOW, BLACK);
    while(1);
}

