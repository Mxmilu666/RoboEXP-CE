#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <GetMagnet.h>
#include <SetInBeep.h>

int main(void)
{
    E2RCU_Init();
    int var0 = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Magnet", YELLOW, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        var0 = GetMagnet(_P1_);
        if ( var0>0 )
        {
            SetDisplayString(3, "YES", YELLOW, BLACK);
            SetInBeep(ON);
        }
        else
        {
            SetDisplayString(3, "NO ", YELLOW, BLACK);
            SetInBeep(OFF);
        }
    }
    while(1);
}

