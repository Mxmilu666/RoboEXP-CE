#ifndef __jmlib_H__
#define __jmlib_H__

#ifdef __cplusplus
 extern "C" {
#endif



#ifdef __cplusplus
}
#endif

#endif /* __jmkernel_H__ */

