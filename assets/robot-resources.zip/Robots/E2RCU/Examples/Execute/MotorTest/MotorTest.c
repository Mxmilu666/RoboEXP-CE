#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetMotor.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    while (1)
    {
        SetMotor(_M1_, 50);
        SetWaitForTime(2);
        SetMotor(_M1_, 0);
        SetWaitForTime(1);
        SetMotor(_M1_, -50);
        SetWaitForTime(2);
        SetMotor(_M1_, 0);
        SetWaitForTime(1);
    }
    while(1);
}

