#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetDTHSensor.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(3, "Temperature:", YELLOW, BLACK);
    SetDisplayString(5, "Humidity:", YELLOW, BLACK);
    while (1)
    {
        var0 = GetDTHSensor(_P1_, 0);
        SetDisplayVar(3, var0, YELLOW, BLACK);
        SetWaitForTime(0.2);
        var0 = GetDTHSensor(_P1_, 1);
        SetDisplayVar(5, var0, YELLOW, BLACK);
        SetWaitForTime(0.2);
    }
    while(1);
}

