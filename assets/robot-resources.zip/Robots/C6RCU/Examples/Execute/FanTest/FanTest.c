#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <SetFan.h>
#include <SetWaitForTime.h>

int main(void)
{
    C6RCU_Init();
    SetLCDBack(ON);
    SetDisplayString(1, "M1", YELLOW, BLACK);
    while (1)
    {
        SetFan(_M1_, 50);
        SetWaitForTime(1);
        SetFan(_M1_, 0);
        SetWaitForTime(1);
    }
    while(1);
}

