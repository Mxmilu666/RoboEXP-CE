#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <SetCalendar.h>
#include <SetWaitForTime.h>
#include <SetBE2560spk.h>

int main(void)
{
    E2RCU_Init();
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        SetCalendar(_P1_, 0, 30, 9, 5, 7, 13);
        SetWaitForTime(1);
        SetBE2560spk(_P1_, 20, 440);
        SetWaitForTime(1);
    }
    while(1);
}

