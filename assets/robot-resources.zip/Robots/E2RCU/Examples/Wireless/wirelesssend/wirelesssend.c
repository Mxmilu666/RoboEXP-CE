#include "HardwareInfo.c"
#include <SetWireless.h>
#include <SetLCD3Char.h>
#include <SetNS.h>

int main(void)
{
    unsigned char data = 175;
    while (1)
    {
        SetWireless(_WIRELESSTXD_1_, data);
        data=data+1;
        SetLCD3Char(3, data);
        SetNS(1);
    }
    return 1;
}

