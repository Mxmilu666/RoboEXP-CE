#ifndef _PINFORMAT_
#define _PINFORMAT_

//0 GPIOA GPIOB GPIOC GPIOD GPIOE
//0    1     2    3      4     5
const uint32_t portarray[6]={0,0x40020000,0x40020400,0x40020800,0x40020C00,0x40021000};
//�˿����ж��� 3 ,4 ,6 ,5 -> SCL,SDC,ADC/TXD,RXD
const uint8_t  RcuPORT[9][4]={{0,0,0,0},{2 ,5 ,1 ,1 }, {5 ,5 ,1 ,1 },//P1 P2
										{5 ,5 ,1 ,2 }, {2 ,2 ,1 ,1 },//P3 P4
										{5 ,5 ,3 ,3 }};//P5
										
const uint8_t  RcuPIN[9][4]={{0,0,0,0},	{2 ,7 ,7 ,4 }, {3 ,2 ,0 ,6 },//P1 P2
										{5 ,4 ,1 ,0 }, {8 ,9 ,2 ,3 },//P3 P4
										{8 ,10 ,4 ,5}};//P5
							
#define _P1_ 1
#define _P2_ 2
#define _P3_ 3
#define _P4_ 4
#define _P5_ 5

#define _M1_ 1
#define _M2_ 2
#define _M3_ 3
#define _M4_ 4

#endif
