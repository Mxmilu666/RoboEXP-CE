#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetLeftButton.h>
#include <GetRightButton.h>
#include <SetDisplayVar.h>
#include <GetcentreButton.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    long var1 = 0;
    long var2 = 0;
    while (1)
    {
        var0 = GetLeftButton();
        var1 = GetRightButton();
        var2 = GetcentreButton();
        SetDisplayVar(1, var0, YELLOW, BLACK);
        SetDisplayVar(2, var1, YELLOW, BLACK);
        SetDisplayVar(3, var2, YELLOW, BLACK);
    }
    while(1);
}

