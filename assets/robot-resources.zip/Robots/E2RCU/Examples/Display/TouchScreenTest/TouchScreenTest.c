#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetTouchScreenX.h>
#include <GetTouchScreenY.h>
#include <SetLCDDot.h>

int main(void)
{
    E2RCU_Init();
    unsigned int var1 = 0;
    unsigned int var2 = 0;
    while (1)
    {
        var1 = GetTouchScreenX();
        var2 = GetTouchScreenY();
        SetLCDDot(var1, var2, YELLOW);
    }
    while(1);
}

