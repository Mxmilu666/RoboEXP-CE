#include "HardwareInfo.c"
#include <GetTouch.h>
#include <SetInBeep.h>

int main(void)
{
    E3RCU_Init();
    unsigned int var0 = 0;
    while (1)
    {
        //
        var0 = GetTouch(_P1_);
        if ( var0==1 )
        {
            SetInBeep(ON);
        }
        else
        {
            SetInBeep(OFF);
        }
    }
    while(1);
}

