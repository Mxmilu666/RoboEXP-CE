#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLED.h>
#include <SetNS.h>

int main(void)
{
    X1RCU_Init();
    while (1)
    {
        SetLED(_LED_1_, 1);
        SetNS(2);
        SetLED(_LED_1_, 0);
        SetNS(2);
    }
    return 1;
}

