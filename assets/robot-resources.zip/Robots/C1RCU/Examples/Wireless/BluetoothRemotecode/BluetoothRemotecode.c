#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetBluetoothControl.h>
#include <Set3CLed.h>

int main(void)
{
   C1RCU_Init();
    long var0 = 0;
    long var1 = 0;
    while (1)
    {
        var0 = GetBluetoothControl();
        if ( var0==2 )
        {
            Set3CLed(_RGB1_, RED);
        }
        else
        {
            if ( var0==4 )
            {
                Set3CLed(_RGB1_, GREEN);
            }
            else
            {
                Set3CLed(_RGB1_, OFF);
            }
        }
    }
    while(1);
}

