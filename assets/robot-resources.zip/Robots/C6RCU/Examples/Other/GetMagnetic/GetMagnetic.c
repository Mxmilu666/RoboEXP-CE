#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetMagnetic.h>
#include <SetDisplayString.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    long var1 = 0;
    while (1)
    {
        var0 = GetMagnetic(_P1_, 0);
        var1 = GetMagnetic(_P1_, 1);
        SetDisplayString(2, "ǿ��:", YELLOW, BLACK);
        SetDisplayString(4, "����:", YELLOW, BLACK);
        SetDisplayVar(3, var0, YELLOW, BLACK);
        SetDisplayVar(5, var1, YELLOW, BLACK);
    }
    while(1);
}

