#ifndef _SERVOCTRL_
#define _SERVOCTRL_ unsigned long
#endif
#ifndef _SERVOCTRL_t_
#define _SERVOCTRL_t_ 428544
#endif
