#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetAICamData.h>
#include <GetAICamData.h>
#include <SetDisplayVar.h>
#include <SetMotor.h>

int main(void)
{
    E3RCU_Init();
    long red = 0;
    long blue = 0;
    SetAICamData(2, 0);
    while (1)
    {
        red = GetAICamData(1);
        blue = GetAICamData(2);
        SetDisplayVar(1, red, YELLOW, BLACK);
        SetDisplayVar(2, blue, YELLOW, BLACK);
        if ( red>0 )
        {
            SetMotor(_M1_, 50);
        }
        else
        {
            if ( blue>0 )
            {
                SetMotor(_M1_, -50);
            }
        }
    }
    while(1);
}

