//rcu sub function compatible
//E6 M6 C6
#include "stm32F4xx_hal.h"

//E7
//#include "stm32h7xx_hal.h"