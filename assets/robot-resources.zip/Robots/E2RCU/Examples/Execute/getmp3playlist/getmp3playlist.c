#include "HardwareInfo.c"
#include <SetNS.h>
#include <SetMp3No.h>
#include <GetMp3No.h>
#include <SetLCD8Char.h>

int main(void)
{
    unsigned char var0 = 0;
    SetNS(3);
    SetMp3No(_MP3_MP3_, 1, 2);
    var0 = GetMp3No(_MP3_MP3_);
    SetLCD8Char(var0, 1, 1);
    SetNS(5);
    SetMp3No(_MP3_MP3_, 1, 1);
    var0 = GetMp3No(_MP3_MP3_);
    SetLCD8Char(var0, 1, 1);
    SetNS(5);
    SetMp3No(_MP3_MP3_, 1, 2);
    var0 = GetMp3No(_MP3_MP3_);
    SetLCD8Char(var0, 1, 1);
    SetNS(5);
    SetMp3No(_MP3_MP3_, 0, 2);
    var0 = GetMp3No(_MP3_MP3_);
    SetLCD8Char(var0, 1, 1);
    SetNS(5);
    return 1;
}

