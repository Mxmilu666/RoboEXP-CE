#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayStr.h>
#include <GetBTModuleRemoteButton.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    long var1 = 0;
    SetDisplayStr(0, 0, "������ֵ", YELLOW, BLACK);
    while (1)
    {
        var1 = GetBTModuleRemoteButton();
        SetDisplayVar(1, var1, YELLOW, BLACK);
    }
    while(1);
}

