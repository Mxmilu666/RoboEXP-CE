#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetRGB.h>
#include <SetWaitForTime.h>

int main(void)
{
   C1RCU_Init();
    while (1)
    {
        SetRGB(0x00FF00, 0x00FF00, 0x00FF00, 0x00FF00, 0x00FF00);
        SetWaitForTime(1);
        SetRGB(0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000);
        SetWaitForTime(1);
        SetRGB(0x0000FF, 0x0000FF, 0x0000FF, 0x0000FF, 0x0000FF);
        SetWaitForTime(1);
    }
    while(1);
}

