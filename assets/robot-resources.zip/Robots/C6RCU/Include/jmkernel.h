#ifndef  _JMKERNEL_H_
#define  _JMKERNEL_H_

#include "stm32f4xx_hal.h"
#include "stm32f4xx.h"
#include <stdint.h>
// #include "pinformat.h"
// #include "I2C_Soft.h"

typedef char* string;

//����ղ���,ͳһMDK��GCC
#if defined (KEIL)//
#define _NOP()	__nop
#elif defined (IAR)
#define _NOP()	asm("NOP")
#else //GCC
#define _NOP()	asm("nop")
#endif

#define _TOUCH_TO_SCREEN_EN_ 1u//��Ļת��ʹ�ܿ���

// #ifdef __JMDK_DATA
// #define __JMDK_DATA
// #ifndef __JMDK_DATA_EXT
// #define __JMDK_DATA_EXT
// // volatile uint8_t g_MotorPowerFlag=0;
// // volatile uint8_t g_M1SpeedPer=100,g_M2SpeedPer=100,g_M3SpeedPer=100,g_M4SpeedPer=100;//��������������ٶȵİٷֱ�
// // volatile uint8_t g_LcdBackLignt=1;//Ĭ�ϱ������
// #endif
// #endif

extern volatile uint8_t g_MotorPowerFlag;
extern volatile uint8_t g_M1SpeedPer,g_M2SpeedPer,g_M3SpeedPer,g_M4SpeedPer;//��������������ٶȵİٷֱ�
extern volatile uint8_t g_LcdBackLignt;//Ĭ�ϱ������

extern volatile uint8_t move_left_port;
extern volatile int32_t move_temporaryVar;
extern volatile uint8_t move_right_port;

extern volatile uint8_t UART2_Sletc;
extern volatile uint32_t AISystemTimeO,AISystemTimeN;
extern volatile uint8_t g_newAInum;
extern uint32_t g_newAILen;

extern unsigned char random_64bytes[64];
extern uint8_t nfc_data[12];
extern uint8_t Encryption_Num;
extern uint8_t NFCRecBuf[14];
extern uint8_t Decrypt_Buff[12];
extern int16_t yaw_now[8],yaw_offset[8];		//��ǰ�ǶȺ�ƫ�ƽǶ�


//�û��ж�������
#define USERISR_IRQ_SIZE	16//�ж���������
typedef enum
{
	TIM1UPIRQ,	//0
	TIM2IRQ,	//1
	TIM8UPIRQ,	//2
	TIM8TRGIRQ,	//3
	TIM8COMIRQ,	//4
	EXTI0IRQ,	//5
	EXTI1IRQ,	//6
	EXTI2IRQ,	//7
	EXTI3IRQ,	//8
	EXTI4IRQ,	//9
	EXTI10IRQ,	//10
	EXTI11IRQ,	//11
	EXTI12IRQ,	//12
	EXTI13IRQ,	//13
	EXTI14IRQ,	//14
	EXTI15IRQ	//15
}USERFUNTON_DEFINED;

/*
typedef struct
{
	int x, y;
	char *filename;
	char scale;
	int state;//��ʾ״̬
} Pic_Typedef;//*/
typedef void (*pUserFunction)(void);//�û�����ָ��

void C6RCU_Init(void);
void GPIO_Setting(GPIO_TypeDef* port,uint16_t pin,uint32_t mode);//GPIO_NOPULL
void GPIO_Setting2(GPIO_TypeDef* port,uint16_t pin,uint32_t mode);//GPIO_PULLUP
void BeepInit(void);
void Beep(uint8_t state);
uint8_t ADC_Configuration(uint32_t SimpleTime,uint8_t channel) ;
uint16_t GetAdcResult(uint8_t channel);
void EepAdr_Init(void);
uint16_t ReadEEP(uint16_t address);
void WriteEEP(uint16_t address,uint16_t data);
uint8_t  SystemTime_init(void);
uint8_t SystemRTC_init(void);
void SetSystemTime(void);
uint32_t GetSystemTime(void);
void delayTenthms(uint32_t Tenthms);
void Delay1ms(float ms);
void Sysdelayus(volatile uint32_t nCount);
uint16_t ReadMotorDir(uint16_t ch);
uint8_t Motor_Init(void);
void MotorFree(uint8_t MotorX);
void SetMotorX(uint8_t MotorX,int8_t Dir,int8_t Speed);
int32_t ReadMotorCnt(uint8_t which);
void ClearMotorCnt(uint8_t which);
uint8_t MotorCodingInit(void);
void SetMotorServoMode(uint8_t MotorX);
void SetMotorNormalMode(uint8_t MotorX);
void MotorCoding_Istr(void);
void SetMotorCnt1Zero(void);
void SetMotorCnt2Zero(void);
void SetMotorCnt3Zero(void);
void SetMotorCnt4Zero(void);
void SetMotorCodeZero(uint8_t motorx);
volatile int32_t GetMotorCnt1(void);
volatile int32_t GetMotorCnt2(void);
volatile int32_t GetMotorCnt3(void);
volatile int32_t GetMotorCnt4(void);
void SetCodeServoAngle(uint8_t MotorX,uint8_t speed,uint32_t Angle);
uint8_t GetTouchValid(void);
uint16_t GetTouchY(void);
uint16_t GetTouchX(void);
uint8_t ReadTouchState(void);
void SetComData(uint8_t data);
uint32_t GetCOMPackData(uint8_t cmd);
void SetCOMByteData(uint8_t cmd0,uint8_t cmd1);
uint32_t GetCOMPackData(uint8_t cmd);
uint8_t GPIO_AdcLed2State(uint8_t which,GPIO_TypeDef *GPIOx,uint8_t Bitx,uint16_t adc,uint8_t mode);//��������״̬
uint16_t ReadInMicVaule(void);
uint16_t ReadInVoltageVaule(void);
void os_task_enter_critical(void);
void os_task_exit_critical(void);
void ReadMotorDirection(uint8_t which, uint8_t direction);
uint64_t ReadCOMData64(void);
void SetMusicPWMFreq(uint16_t freq);
////////////move/////////////////////////
void Set_Wait_For_Angle(uint8_t which,int speed,int32_t Angle);
void Move_Speed(int32_t speedl,int32_t speedr);
void Move_Stop(void);
void Move_Power(int32_t speedl,int32_t speedr);
////////////////////////////////////////

////////////ѭ����///////////////////////
extern uint8_t TRACE_ADDR;
uint8_t Set_Encryp(uint8_t data);
uint8_t Get_Decry(uint8_t data);

extern uint8_t TraceThresholdState;
extern uint8_t TraceLineColor[8];//ѭ�������ڻ���ߣ��ڸ�λʱ����
void Set_TraceV2I2CLineColor(uint8_t which,uint8_t color);

// #include "jmkernel.h"
// uint8_t Get_TraceV2I2CState( uint8_t which, uint8_t bit);
////////////////END/////////////////////////

void Change_Motor_Dir(uint8_t which,uint8_t dir);
void ChangeMotorDirection(uint8_t which,uint8_t dir);
void Set_Motor_X(uint8_t which,int speed);
void Set_Motor_Code(uint8_t which);
int32_t Get_Motor_Code(uint8_t which);
void Set_Motor_Speed(which,speed);

///////////////2024-05-22/////������////////////
// int16_t GetHCSR04(GPIO_TypeDef *GPIOx1,uint8_t Bitx1 ,GPIO_TypeDef *GPIOx2,uint8_t Bitx2);

///////////////2024-05-22/////��˷�////////////
extern uint8_t Flag_ADS[5];
uint32_t Get_PortX_ADCVal(uint8_t which);

/////////////////////////////////////////////////////
void HCSR04_ISR(void);
////////////////////////////////////////////////////
void HCSR04_TIM3_Init(void);
extern volatile uint8_t HCSR04_D;
extern volatile uint16_t HCSR04_distance; 
extern uint32_t HCSR04_port1;
extern uint8_t HCSR04_bit1;

uint16_t ReadAdcThreshold(uint8_t px);
////////////////////////////////NFC///////////////////////////
extern unsigned char random_64bytes[64];
extern uint8_t nfc_data[12];
extern uint8_t NFCRecBuf[14];
extern uint8_t Encryption_Num;
uint8_t SetEncryptorByte1(uint8_t offest,uint8_t data,uint8_t F);//����
uint8_t GetDecryptionByte1(uint8_t offest,uint8_t data,uint8_t F);//����
int16_t NFCShow(void);
//////////////////////////////////////////////////////////////
uint32_t GetSystemTime(void);
void SetSystemTime(void);
void Delay1ms(float ms);//1ms Ϊ��λ
extern int16_t yaw_now[8];
extern int16_t yaw_offset[8];
///////////////////////////////////////////////////////////
////////////////////////////AICam///////////////////////////////
void SetNewAIPackData(uint8_t cmd);
uint32_t GetNewAIPackData(uint8_t num, uint8_t cmd);
void SetNewAIPackNameStr(uint8_t cmd);
char* GetNewAIPackName(uint8_t num);
uint16_t GetNewAIPackIDData(uint8_t id,uint8_t cmd);
char* GetNewAIPackIDName(uint8_t id);
void SendNewAIData(uint8_t name,uint8_t mode);
void SendNewAIStr(char* name,uint8_t mode);
uint8_t SetWaitNewAISetName(void);
void GetNewAIPackDatas(void);
////////////////////////////////////////////////////////////////

#endif
