#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetData.h>
#include <GetData.h>
#include <SetRGB.h>

int main(void)
{
   C1RCU_Init();
    unsigned int var0 = 0;
    SetData(1, 55);
    var0 = GetData(1);
    SetRGB(0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000);
    while(1);
}

