#ifndef _JMLIB_H_
#define _JMLIB_H_

#define __JMDK_DATA
//#include <jmkernel32.h>
//#include "HardwareInfo.h"

#define _SETSYSTIME_
#define _GETSYSTIME_

#define _SETDATA_
#define _GETDATA_

#define _SETFONTSIZE_
#define _SETLCDBACK_
#define _SETDISPLAYSTRING_
#define _SETDISPLAYVAR_
#define _SETDISPLAYVARU32_
#define _SETDISPLAYFLOAT_
#define _SETDISPLAYSTRINGXY_
#define _SETDISPLAYVARXY_
#define _SETDISPLAYSTR_
#define _SETDISPLAYVARIABLE_



#define _SETWAITFORTIME_ 

#define _SETLIGHTSENSORILAMP_
#define _SETLIGHTSENSORTHRESHOLD_
#define _GETLIGHTSENSORTHRESHOLD_
#define _SETLIGHTSENSORLED_
#define _GETLIGHTSENSOR_
#define _GETLIGHTSENSORDATA_
#define _GETANTILIGHT_
#define _SETWAITFORDARK_
#define _SETWAITFORLIGHT_

#define _SETDISPLAYVAR_
#define _SETDISPLAYVARU32_

#define _SETDISPLAYPICTURE_
#define _SETDISPLAYPICTURE_


#define _GETINVOTAGE_
#define _GETINMIC_

#define _SETSMARTEYEMODE_

#define _SETINBEEP_
#define _GETLEFTBUTTON_
#define _GETRIGHTBUTTON_

#define _GETTOUCH_
#define _GETCHOICEBOX_
#define _GETTOUCHSCREENX_
#define _GETTOUCHSCREENY_
#define _GETTOUCHSCREEN_
#define _SETTOUCHTOSCREENCOORDINATE_




#define _GETCOLORSENSOR_
#define _GETCOLORSENSORRGB_
#define _SETCOLORSENSOR_


#define _GETULTRASOUND_

#define _SETMOTOR_
#define _SETMOTORSERVO_
#define _SETWAITFORANGLE_
#define _SETMOTORSTRAIGHTANGLE_
#define _SETWAITFORSTRAIGHT_
#define _SETCARTURN_
#define _SETWAITFORCARTURN_
#define _SETMOTORSTRAIGHT_
#define _SETMOTORSTRAIGHTTURN_
#define _SETMOTORFREE_


#define _SETSERVO_
#define _SETSERVOTIME_


#define _GETMOTORCODE_
#define  _SET3CLED_

#define _SETUARTDATA_
#define _GETUARTDATA_
#define _GETWIFICAMCTRL_
#define _GETBLUETOOTHCONTROL_
#define _SETBLUETOOTHDATA_
#define _GETBLUETOOTHDATA_
#define _GETWIFICAMROCKCTRL_


#define _SETMP3PLAY_
#define _SETMP3SUSPEND_

#define _SETINSOUND_
#define _SETNOTE_
#define _SETMUSICADDDATA_
#define _SETMUSICPLAY_


#define _GETDTHSENSOR_
#define _GETLASERDIST_


#define _GETBTMODULEREMOTEBUTTON_
#define _GETBTMODULEREMOTECODE_
#define _GETBTMODULEREMOTEROCKER_

#define _GETCOMVOICE_
#define _GETAICAMDATA_
#define _SETDISPLAYLATTICEPIC_
#define _SETDISPLAYLATTICE_

#define _SETPIDMOTORVALUE_
#define _SETPIDMOTORSPEED_

#define _DISPLAY_SHOW_IMAGE_
#define _BLUETOOTH_SET_NAME_


/*





#define _GETBLUETOOTH_
#define _SETBLUETOOTH_
#define _GETINMIC_
#define _GETCOMPASSB_
#define _GETCOMPOI_
#define _GETAHRS_


#define _GETTOUCH_

#define _SETDISPLAYVAR_
#define _SETDISPLAYSTRING_
#define _SETLCDCLEAR_
#define _SETLCDDOT_
#define _SETLCDSOLIDCIRCLE_
#define _SETLCDFILLEDRECTANGLE_
#define _SETLCDRECTANGLE_
#define _SETINSOUND_
#define _GETDATA_
#define _SETMUSICADDDATA_
#define _SETMUSICREPEAT_
#define _SETMUSICPLAY_

#define _SETMOTORSTRAIGHTANGLE_
#define _SETMOTORSTRAIGHTSTOP_
#define _SETWAITFORSTRAIGHT_
#define _SETCARTURN_
#define _SETWAITFORCARTURN_
#define _GETIRCODE_
#define _SETIRCODE_
#define _GETRANDOM_
//WIFI
#define _SETWIFIDATA_
#define _GETWIFIDATA_
#define _GETWIFIPUTTER_
#define _GETWIFIREMOTE_
#define _SETDISPLAYPICTURE_
#define _SETMOTORCODE_
#define _SETWIFIUDPMODE_
*/

/*
void SetMusicPlay(void);
void SetMusicRepeat(int c);
void SetMusicAddData(u8 mdata,int time);
void SetInSound(int freq,int time);
//void SetMotor(u8 which,u8 speed);
void SetMotor(u8 which,int speed);
  void SetWaitForTime(float s);
  void SetLightSensorLed(u8 which,int state);
  u16 GetAntiLight(u8 which);
  u16 GetLightSensor(u8 which);
  void SetWaitforDark(u8 which,u16 value);
  u16 SetWaitforLight(u8 which,u16 value);
  u16 SetWaitforDarker(u8 which,u16 value);
  u16 SetWaitforLighter(u8 which,u16 value);
  u16 GetTouch(u8 which);
u16 GetTouchA(u8 which);
u16 GetTouchB(u8 which);
  void SetLCDBack(u8 led);
//void SetDisplayVar(u16 y,u32 data,u16 ch_color,u16 bg_color);
void SetLCDClear(u16 m_color);
void SetLCDDot(u8 x,u16 y,u16 m_color);
void SetLCDPicture(u8 x,u16 y,u8 num);
u8 GetChoiceBox(u8* words);
//void SetDisplayString(u16 y,u8* pic,u16 ch_color,u16 bg_color);
void SetDisplayString(int y,s8* pic,u16 ch_color,u16 bg_color);
void Set3CLed(u8 which,u16 Color);
//void SetMotor(u8 which,u8 speed);
void SetMotorCode(u8 which);
vs32 GetMotorCode(u8 which);
u32 GetSysTime(void);
void SetSysTime(void);
u16 GetData(int dataadr);
void SetData(u8 dataadr,u16 datacode);
u8 GetLeftButton(void);
u8 GetRightButton(void);
u16 GetTouchScreen(void);
u16 GetTouchScreenX(void);
u16 GetTouchScreenY(void);
u16 GetInMic(void);
void SetWaitforLoud(u16 value);
void SetWaitforQuiet(u16 value);
void SetWaitforLouder(u16 value);
void SetWaitforQuieter(u16 value);
u16 GetInVotage(void);
  void SetInBeep(u8 state);
//void SetMotorServo(u8 which,u8 speed,u32 Angle);
void SetMotorServo(u8 which,int speed,s32 Angle);
//void SetWaitForAngle(u8 which,u8 speed,u32 Angle);
void SetWaitForAngle(u8 which,int speed,s32 Angle);
void SetMotorServo128(u8 which,int speed,s32 Angle);
void SetWaitForPress(u8 which);
void SetWaitForRelease(u8 which);
void SetWaitForBump(u8 which);
u32 GetNumberOfClicks(u8 which);
u16 GetUltrasound(u8 which,u8 mode);
u8 GetCompoI(u8 which, u8 command);
u16 GetCompassB(u8 which);
void ADXL345_Write(u8 Reg,u8 Data);
void gSense_Init(void);
int GetGSensor(u8 which,u8 axis);
u16 GetBluetooth(void)  ;
void SetBluetooth(u8 data)  ;
void SetFan(u8 which,u8 speed);
void SetIR(u8 which,u8 state);
u8 GetIRDete(u8 which);
u16 GetIRDist(u8 which);
u16 GetInfrared(u8 which);
u16 GetRemoIR(u8 which);
u16 GetVolume(u8 which);
u16 GetVoltage(u8 which);
int GetCurrent(u8 which);
u16 GetPhoto(u8 which);
u8 GetMagnet(u8 which);
u16 GetDTHSensor(u8 which,u8 mode);
u8 GetAirQuality(u8 which);
void SetMusicPlayer(u8 which, u8 cmd);
u8 GetIR(u8 whichs,u8 whichr,u8 state);
void SetWaitForBluetooth(u8 data)  ;
void SetPIDMotor(u8 which,u8 speed);
void SetPIDMotorRef(u8 pulse);
unsigned char GetCalendar(u8 which, unsigned char command);
void SetCalendar(u8 which, unsigned char sec,unsigned char min,unsigned char hour,unsigned char date,unsigned char month,unsigned char year);
void SetBE2560LCD1(u8 which, unsigned char command,unsigned char lx,unsigned char lxdchar);
void SetBE2560Back(u8 which, unsigned char led);
void SetBE2560LCD3(u8 which, unsigned char lx,unsigned int lxdint);
void SetBE2560LCD8(u8 which, unsigned char lx,unsigned long lxdlong);
void SetBE2560spk(u8 which, unsigned char time,unsigned int freq);
void SetTouchToScreenCoordinate(void);
void SetAHRS(u8 which,u8 command);
s16 GetAHRSRecBuf(u8 which,u8 cnt);
s16 GetAHRS(u8 which,u8 command1,u8 command2);
u8 SetExtBluetoothMode(u8 *name,u8 *mode,u8 *pswd);
void SetExtBluetooth(u8 data);
u16 GetExtBluetooth(void);
u8 SetExtBluetoothCmd(u8 mode,u8 *strcmd,u8 *str);
u32 GetRemoteControllerButton(void);
u16 GetRemoteControllerButtonState(void);
u32 GetRemoteControllerRocker(u8 dir,u8 axis);
s16 GetRemoteControllerGravity(u8 i);
s16 GetRemoteControllerEulerian(u8 i);
//void SetLCDSolidCircle(u16 x,u16 y,u16 radius,u16 color);
//void SetLCDFilledRectangle(u16 x1,u16 y1,u16 x2,u16 y2,u16 color);
//void SetLCDRectangle(u16 x1,u16 y1,u16 x2,u16 y2,u16 w,u16 color);
void SetLCDSolidCircle(int x,int y,u16 radius,u16 color);
void SetLCDFilledRectangle(int x1,int y1,int x2,int y2,u16 color);
void SetLCDRectangle(int x1,int y1,int x2,int y2,int w,u16 color);
u32 GetColorSensor(u8 which,u8 cmd);
u32 SetColorSensor(u8 which,u8 cmd,u16 parameter);
void SetServo(u8 which,u8 angle);
u8 SetMusicNote(u8 which,u8 m_note,u8 m_meter,u8 m_pitch,u8 m_scale);
u8 GetTraceV2I2C( u8 which, u8 command);
void SetTraceV2Color(u8 which,u8 ch1,u8 ch2,u8 ch3,u8 ch4,u8 ch5,u8 ch6,u8 ch7);
void SetTraceV2BeepI2C( u8 which,u8 beeptime);
void SetTraceV2PercentI2C( u8 which,u8 molecular,u8 denominator);
void SetMotorPower(u8 m_Per1,u8 m_Per2,u8 m_Per3,u8 m_Per4);

*/


#endif
