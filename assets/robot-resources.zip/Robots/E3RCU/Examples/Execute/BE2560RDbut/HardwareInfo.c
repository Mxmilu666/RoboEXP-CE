#ifndef _CALENDAR_
#define _CALENDAR_ unsigned long
#endif
#ifndef _CALENDAR_1_
#define _CALENDAR_1_ 33152
#endif
