#ifndef _JMSUB1_
#define _JMSUB1_
#include "HardwareInfo.c"
#include <SetWaitForTime.h>

void JMSub1()
{
    SetWaitForTime(1);
}
#endif

