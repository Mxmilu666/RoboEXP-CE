#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetSwitch.h>
#include <SetNS.h>

int main(void)
{
    X1RCU_Init();
    while (1)
    {
        SetSwitch(_SWITCH_1_, 0);
        SetNS(2);
        SetSwitch(_SWITCH_1_, 1);
        SetNS(2);
    }
    return 1;
}

