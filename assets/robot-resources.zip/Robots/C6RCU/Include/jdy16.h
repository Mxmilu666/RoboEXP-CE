#ifndef _JDY16_H_
#define _JDY16_H_

#include "stm32f4xx_hal.h"
#include "stm32f4xx.h"
#include <stdint.h>

extern uint8_t BTName[20];
volatile uint8_t BTroker2RcuData[16];
uint8_t BlueTH_Init(uint32_t baud);
void BlueTH_SetATmode(uint8_t stat);
void BlueTH_RX_ISR(void);
void BluetoothProcess(void);
void RockerDelayTimInit(void);
uint8_t BlueTH_IsConnect(void);
void JDY16_GetName(void);

#endif