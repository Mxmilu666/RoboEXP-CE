#include "HardwareInfo.c"
#include <SetDisplayString.h>
#include <GetCalendar.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E3RCU_Init();
    unsigned char butA = 0;
    unsigned char butB = 0;
    unsigned char butC = 0;
    unsigned char butD = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "A", YELLOW, BLACK);
    SetDisplayString(3, "B", YELLOW, BLACK);
    SetDisplayString(4, "C", YELLOW, BLACK);
    SetDisplayString(5, "D", YELLOW, BLACK);
    while (1)
    {
        butA = GetCalendar(_P1_, 38);
        SetDisplayVar(2, butA, YELLOW, BLACK);
        butB = GetCalendar(_P1_, 39);
        SetDisplayVar(3, butB, YELLOW, BLACK);
        butC = GetCalendar(_P1_, 40);
        SetDisplayVar(4, butC, YELLOW, BLACK);
        butD = GetCalendar(_P1_, 41);
        SetDisplayVar(5, butD, YELLOW, BLACK);
        SetWaitForTime(0.02);
    }
    while(1);
}

