#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetLightSensor.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    unsigned int var0 = 0;
    while (1)
    {
        var0 = GetLightSensor(_P1_);
        SetDisplayVar(1, var0, YELLOW, BLACK);
        SetWaitForTime(0.1);
    }
    while(1);
}

