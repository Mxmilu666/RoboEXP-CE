#include "HardwareInfo.c"
#include <SetSCUServo.h>
#include <SetNS.h>

int main(void)
{
    unsigned char angle = 10;
    while (1)
    {
        SetSCUServo(_SERVOCTRL_t_, 0, 0, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 1, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 2, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 3, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 4, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 5, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 6, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 7, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 8, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 9, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 10, angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 11, angle);
        SetSCUServo(_SERVOCTRL_t_,0,12,angle);
        SetSCUServo(_SERVOCTRL_t_,0,13,angle);
        SetSCUServo(_SERVOCTRL_t_,0,14,angle);
        SetSCUServo(_SERVOCTRL_t_, 0, 15, angle);
        SetNS(2);
        if ( angle>127 )
        {
            angle=10;
        }
        else
        {
            angle=240;
        }
    }
    return 1;
}

