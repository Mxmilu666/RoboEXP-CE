#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <GetRFModuleRemoteBit.h>
#include <GetRFModuleRemoteRocker.h>
#include <SetMotor.h>
#include <Set3CLed.h>
#include <SetInSound.h>
#include <SetWaitForTime.h>
#include <SetDisplayVar.h>

// define global var
int g_speed1 = 50;
int g_speed2 = 50;

int main(void)
{
    C6RCU_Init();
    unsigned int var1 = 0;
    unsigned int var2 = 0;
    unsigned int var3 = 0;
    unsigned int var4 = 0;
    unsigned int var5 = 0;
    unsigned int var6 = 0;
    unsigned int var7 = 0;
    unsigned int var8 = 0;
    unsigned int var9 = 0;
    unsigned int var10 = 0;
    unsigned int var11 = 0;
    int speed1 = 50;
    int speed2 = 50;
    unsigned int var0 = 0;
    long var12 = 0;
    long var13 = 0;
    SetDisplayString(1, "speed", YELLOW, BLACK);
    SetDisplayString(2, "turn", YELLOW, BLACK);
    while (1)
    {
        var1 = GetRFModuleRemoteBit(_P1_, 1);
        var2 = GetRFModuleRemoteBit(_P1_, 2);
        var3 = GetRFModuleRemoteBit(_P1_, 3);
        var4 = GetRFModuleRemoteBit(_P1_, 4);
        var5 = GetRFModuleRemoteBit(_P1_, 5);
        var6 = GetRFModuleRemoteBit(_P1_, 6);
        var7 = GetRFModuleRemoteBit(_P1_, 7);
        var8 = GetRFModuleRemoteBit(_P1_, 8);
        var9 = GetRFModuleRemoteBit(_P1_, 9);
        var10 = GetRFModuleRemoteBit(_P1_, 10);
        var11 = GetRFModuleRemoteBit(_P1_, 11);
        var0 = GetRFModuleRemoteBit(_P1_, 0);
        var12 = GetRFModuleRemoteRocker(_P1_, 0, 1);
        var13 = GetRFModuleRemoteRocker(_P1_, 1, 1);
        if ( var5==1 )
        {
            speed1=g_speed1;speed2=g_speed1;
            SetMotor(_M1_, speed1);
            SetMotor(_M2_, speed2);
        }
        if ( var6==1 )
        {
            speed1=0-g_speed2;speed2=0-speed1;
            SetMotor(_M1_, speed1);
            SetMotor(_M2_, speed2);
        }
        if ( var7==1 )
        {
            speed1=0-g_speed1;speed2=0-g_speed1;
            SetMotor(_M1_, speed1);
            SetMotor(_M2_, speed2);
        }
        if ( var8==1 )
        {
            speed1=g_speed2;speed2=0-speed1;
            SetMotor(_M1_, speed1);
            SetMotor(_M2_, speed2);
        }
        if ( var12!=0&&var12!=999 )
        {
            var12=(char)var12*g_speed1/100;
            SetMotor(_M2_, var12);
        }
        if ( var13!=0&&var13!=999 )
        {
            var13=(char)var13*g_speed1/100;
            SetMotor(_M1_, var13);
        }
        if ( var8==0&&var7==0&&var6==0&&var5==0 )
        {
            if ( var13==0||var13==999 )
            {
                SetMotor(_M1_, 0);
            }
            if ( var12==0||var12==999 )
            {
                SetMotor(_M2_, 0);
            }
        }
        if ( var9==1||var10==1 )
        {
            Set3CLed(_P4_, BLUE);
            SetInSound(262, 200);
            SetWaitForTime(0.2);
        }
        else
        {
            Set3CLed(_P5_, OFF);
        }
        if ( var11==1||var0==1 )
        {
            Set3CLed(_P5_, BLUE);
            SetInSound(294, 200);
            SetWaitForTime(0.2);
        }
        else
        {
            Set3CLed(_P5_, OFF);
        }
        if ( var1==1 )
        {
            g_speed1=g_speed1+10;
            if ( g_speed1>=100 )
            {
                g_speed1=100;
            }
            SetInSound(262, 200);
            SetWaitForTime(0.2);
        }
        if ( var3==1 )
        {
            g_speed1=g_speed1-10;
            if ( g_speed1<=30 )
            {
                g_speed1=30;
            }
            SetInSound(330, 200);
            SetWaitForTime(0.2);
        }
        if ( var4==1 )
        {
            g_speed2=g_speed2+10;
            if ( g_speed2>100 )
            {
                g_speed2=100;
            }
            SetInSound(349, 200);
            SetWaitForTime(0.2);
        }
        if ( var2==1 )
        {
            g_speed2=g_speed2-10;
            if ( g_speed2<30 )
            {
                g_speed2=30;
            }
            SetInSound(294, 200);
            SetWaitForTime(0.2);
        }
        SetDisplayVar(1, g_speed1, YELLOW, BLACK);
        SetDisplayVar(2, g_speed2, YELLOW, BLACK);
    }
    while(1);
}

