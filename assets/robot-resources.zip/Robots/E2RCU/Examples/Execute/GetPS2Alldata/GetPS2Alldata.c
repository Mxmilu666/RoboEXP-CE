#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <GetPS2All.h>
#include <SetLCD3Char.h>

// define global var
unsigned char m_Btn1 = 0;
unsigned char m_Btn2 = 0;
unsigned char m_joy1_X = 0;
unsigned char m_joy1_Y = 0;
unsigned char m_joy2_X = 0;
unsigned char m_joy2_Y = 0;

int main(void)
{
    X1RCU_Init();
    SetLCDBack(1);
    while (1)
    {
        GetPS2All(_PS2_1_);
        SetLCD3Char(0, 0, m_Btn1);
        SetLCD3Char(64, 0, m_Btn2);
        SetLCD3Char(0, 2, m_joy1_Y);
        SetLCD3Char(64, 2, m_joy2_Y);
    }
    return 1;
}

