#include "HardwareInfo.c"
#include <SetWaitForAngle.h>
#include <SetInBeep.h>

int main(void)
{
    E3RCU_Init();
    SetWaitForAngle(_M1_, 50, 270);
    SetInBeep(ON);
    SetWaitForAngle(_M1_, -50, 270);
    SetInBeep(OFF);
    while(1);
}

