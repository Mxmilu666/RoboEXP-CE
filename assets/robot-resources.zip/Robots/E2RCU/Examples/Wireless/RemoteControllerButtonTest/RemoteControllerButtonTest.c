#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetRemoteControllerButtonState.h>
#include <SetDisplayVar.h>

int main(void)
{
    E2RCU_Init();
    unsigned int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "Remote Controller", YELLOW, BLACK);
    SetDisplayString(2, "Button State", YELLOW, BLACK);
    while (1)
    {
        var0 = GetRemoteControllerButtonState();
        SetDisplayVar(3, var0, YELLOW, BLACK);
    }
    return 1;
}

