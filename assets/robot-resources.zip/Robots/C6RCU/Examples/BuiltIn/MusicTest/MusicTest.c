#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetMusicAddData.h>
#include <SetMusicRepeat.h>
#include <SetMusicPlay.h>

int main(void)
{
    C6RCU_Init();
    SetMusicAddData(6, 4);
    SetMusicAddData(8, 4);
    SetMusicAddData(10, 4);
    SetMusicAddData(8, 4);
    SetMusicAddData(9, 6);
    SetMusicAddData(8, 4);
    SetMusicAddData(7, 4);
    SetMusicAddData(10, 6);
    SetMusicAddData(9, 6);
    SetMusicAddData(6, 5);
    SetMusicAddData(8, 4);
    SetMusicAddData(10, 4);
    SetMusicAddData(12, 4);
    SetMusicAddData(12, 4);
    SetMusicAddData(13, 6);
    SetMusicAddData(12, 4);
    SetMusicAddData(11, 4);
    SetMusicAddData(10, 5);
    SetMusicAddData(11, 6);
    SetMusicAddData(12, 6);
    SetMusicAddData(14, 4);
    SetMusicAddData(13, 4);
    SetMusicAddData(10, 4);
    SetMusicAddData(10, 4);
    SetMusicAddData(7, 6);
    SetMusicAddData(6, 4);
    SetMusicAddData(10, 4);
    SetMusicAddData(9, 4);
    SetMusicAddData(11, 6);
    SetMusicAddData(11, 4);
    SetMusicAddData(0, 4);
    SetMusicAddData(12, 4);
    SetMusicAddData(11, 4);
    SetMusicAddData(10, 6);
    SetMusicAddData(9, 4);
    SetMusicAddData(8, 4);
    SetMusicAddData(10, 6);
    SetMusicAddData(9, 6);
    SetMusicAddData(6, 5);
    SetMusicAddData(6, 4);
    SetMusicRepeat(1);
    SetMusicPlay();
    while (1)
    {
    }
    while(1);
}

