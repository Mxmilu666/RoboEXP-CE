#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetFontSize.h>
#include <SetDisplayString.h>
#include <SetIRBoard.h>
#include <SetWaitForTime.h>

int main(void)
{
    E3RCU_Init();
    SetFontSize(1);
    SetDisplayString(1, "P1 BE1319", YELLOW, BLACK);
    while (1)
    {
        SetIRBoard(_P1_, 0, 0, 2);
        SetWaitForTime(1);
        SetIRBoard(_P1_, 0, 0, 8);
        SetWaitForTime(1);
        SetIRBoard(_P1_, 0, 0, 32);
        SetWaitForTime(1);
    }
    while(1);
}

