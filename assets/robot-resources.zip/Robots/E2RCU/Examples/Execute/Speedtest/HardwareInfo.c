#ifndef _MOTOR_
#define _MOTOR_ unsigned long
#endif
#ifndef _SCABLEAD_
#define _SCABLEAD_ unsigned long
#endif
#ifndef _MOTOR_1_
#define _MOTOR_1_ 20736
#endif
#ifndef _MOTOR_2_
#define _MOTOR_2_ 153856
#endif
#ifndef _SCABLEAD_1_
#define _SCABLEAD_1_ 2048
#endif
