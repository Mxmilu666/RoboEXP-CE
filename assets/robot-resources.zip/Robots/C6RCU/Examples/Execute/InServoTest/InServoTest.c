#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetMotorServo.h>
#include <SetWaitForTime.h>
#include <SetInBeep.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    SetMotorServo(_M1_, 50, 270);
    SetWaitForTime(1);
    SetInBeep(ON);
    SetMotorServo(_M1_, -50, 270);
    SetWaitForTime(1);
    SetInBeep(OFF);
    while(1);
}

