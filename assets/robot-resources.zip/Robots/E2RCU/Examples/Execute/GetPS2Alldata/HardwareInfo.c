#ifndef _PS2_
#define _PS2_ unsigned long
#endif
#ifndef _PS2_1_
#define _PS2_1_ 4384
#endif
