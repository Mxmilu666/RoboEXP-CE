#ifndef _RFID_
#define _RFID_ unsigned long
#endif
#ifndef _RFID_RFID_
#define _RFID_RFID_ 428544
#endif
