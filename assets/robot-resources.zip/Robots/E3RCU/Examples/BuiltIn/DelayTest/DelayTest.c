#include "HardwareInfo.c"
#include <SetInBeep.h>
#include <SetWaitForTime.h>

int main(void)
{
    E3RCU_Init();
    SetInBeep(ON);
    SetWaitForTime(1);
    SetInBeep(OFF);
    SetWaitForTime(1);
    while(1);
}

