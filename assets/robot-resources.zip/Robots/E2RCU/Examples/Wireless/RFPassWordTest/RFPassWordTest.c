#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetRightButton.h>
#include <SetRFPassWord.h>
#include <SetInBeep.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    unsigned int btn1 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Right button setting passwor", YELLOW, BLACK);
    while (1)
    {
        btn1 = GetRightButton();
        if ( btn1==1 )
        {
            SetRFPassWord(_P1_, 1234567);
            SetInBeep(ON);
            SetWaitForTime(0.1);
            SetInBeep(OFF);
            SetWaitForTime(0.1);
        }
    }
    return 1;
}

