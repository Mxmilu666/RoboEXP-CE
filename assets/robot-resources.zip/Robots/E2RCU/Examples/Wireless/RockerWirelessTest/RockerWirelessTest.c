#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <GetRockerWireless.h>
#include <SetLCD3Char.h>

// define global var
unsigned int rockerl_x = 0;
unsigned int rockerl_y = 0;
unsigned int rockerr_x = 0;
unsigned int rockerr_y = 0;

int main(void)
{
    X2RCU_Init();
    SetLCDBack(1);
    while (1)
    {
        GetRockerWireless(_WIRELESS_1_, "1234567");
        SetLCD3Char(0, 0, rockerl_x, YELLOW, BLACK);
        SetLCD3Char(80, 0, rockerl_y, YELLOW, BLACK);
        SetLCD3Char(0, 16, rockerr_x, YELLOW, BLACK);
        SetLCD3Char(80, 16, rockerr_y, YELLOW, BLACK);
    }
    return 1;
}

