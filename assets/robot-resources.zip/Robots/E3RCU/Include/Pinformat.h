#ifndef _PINFORMAT_
#define _PINFORMAT_

const u32 portarray[6]={0,0x40010800,0x40010c00,0x40011000,0x40011400,0x40011800};
                          //�˿����ж��� 3 ,4 ,6 ,5 -> SCL,SDC,ADC/TXD,RXD
const u8  RcuPORT[9][4]={{0,0,0,0},	{5 ,5 ,1 ,0 },{5 ,2 ,1 ,0 },//P1 P2
																				{5 ,5 ,1 ,0 },{5 ,5 ,1 ,0 },//P3 P4
																				{5 ,5 ,3 ,0 },{5 ,5 ,1 ,0 },//P5 P6
																				{5 ,5 ,3 ,0 },{2 ,2 ,1 ,1 }};//P7 P8
const u8  RcuPIN[9][4]={{0,0,0,0},		{9 ,8 ,7 ,0 },{7 ,2 ,6 ,0 },//P1 P2
																				{5 ,4 ,0 ,0 },{3 ,2 ,5 ,0 },//P3 P4
																				{11,10,4 ,0 },{1 ,0 ,1 ,0 },//P5 P6
																				{13,12,5 ,0 },{8 ,9 ,2 ,3 }};//P7 P8

#define _P1_ 1
#define _P2_ 2
#define _P3_ 3
#define _P4_ 4
#define _P5_ 5
#define _P6_ 6
#define _P7_ 7
#define _P8_ 8

#define _M1_ 1
#define _M2_ 2
#define _M3_ 3
#define _M4_ 4
//����E2RCU
#define E2PORT RcuPORT 
#define E2PIN  RcuPIN
#endif
