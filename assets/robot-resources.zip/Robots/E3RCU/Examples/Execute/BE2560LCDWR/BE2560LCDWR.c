#include "HardwareInfo.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <SetWaitForTime.h>
#include <SetBE2560LCD1.h>
#include <SetBE2560Back.h>
#include <SetBE2560LCD3.h>
#include <SetBE2560LCD8.h>

int main(void)
{
    E3RCU_Init();
    unsigned long var0 = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetLCDBack(ON);
    SetWaitForTime(1);
    while (1)
    {
        SetBE2560LCD1(_P1_, 54, 1, 56);
        SetWaitForTime(1);
        SetBE2560LCD1(_P1_, 50, 1, 'A');
        SetWaitForTime(1);
        SetBE2560Back(_P1_, 1);
        SetWaitForTime(1);
        SetBE2560LCD1(_P1_, 55, 1, 56);
        SetWaitForTime(1);
        SetBE2560LCD3(_P1_, 1, 123);
        SetWaitForTime(1);
        SetBE2560LCD1(_P1_, 50, 1, 56);
        SetWaitForTime(1);
        SetBE2560Back(_P1_, 0);
        SetWaitForTime(1);
        SetBE2560LCD8(_P1_, 0, 12345678);
        SetWaitForTime(1);
        SetBE2560LCD8(_P1_, 1, 12345678);
        SetWaitForTime(1);
    }
    while(1);
}

