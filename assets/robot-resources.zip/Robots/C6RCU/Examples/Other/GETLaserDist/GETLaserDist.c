#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <GetLaserDist.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    long var1 = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "������", YELLOW, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        var0 = GetLaserDist(_P1_, 0);
        SetDisplayVar(2, var0, YELLOW, BLACK);
    }
    while(1);
}

