#ifndef _BLUETOOTH_
#define _BLUETOOTH_

#include "stm32f10x_lib.h"

#define BT_SLAVE	"0"//�ӻ�
#define BT_MASTER	"1"//����
#define BT_LOOP	"2"//�ػ�

typedef enum//����ģʽ
{
	BT_NormalMode=0,
	BT_ATMode
}BTMode_Defined;

typedef enum 
{
	DEMAND=0,         //��ѯ
	SITE	  		//����
}BT_MODE_DEFIENED;
typedef enum RX_STATUS//״̬ö��
{
	BT_NONE = 0,
	BT_SUCCESS ,
	BT_ERROR ,
	BT_OVERTIME,
	BT_FALSE
}BT_STATUS_TYPEDEF;

typedef enum 
{
	SPECIF_CM='0',
	ANY_CM='1',
	LOOP_CM='2'
}CMODE_DEFINED;
typedef enum 
{
	BT_NCBAUD = 0,
	BT_BAUD115200,
	BT_BAUD9600,
	BT_BAUD38400
}BT_BAUD_DEFINED;

void BT_Delayms(unsigned long nCount);
u8 ExtBT_PinInit(void);
void SetBTUsartBaudTimer(u32 m_baud);
void ExtBT_ComInit(u32 m_baud);
void ExtBT_Strcat(u8* str1,u8* str2,u8* strnew);
//***************************************************************************
//****************** ����Ϊ���ڷ�������պ��� *******************************
//***************************************************************************
void Soft_Usart_Delay_NVIC_Config(void);
void Soft_Usart_Delay_TimInit(void);
void Soft_Usart_Char(u8 data);
void TIM7_ISR(void);
void ExtBT_Char(u8 ch);
void ExtBT_String(u8 *str);
//*************************************************************************
//************************* �ⲿ������ ************************************
//*************************************************************************
void ExtBT_ReadString(u8 *str,u8 *strnew);
BT_STATUS_TYPEDEF ExtBT_AT_Cmd(u8 *str);
BT_STATUS_TYPEDEF ExtBT_GetATTestState(u32 m_baud);
BT_BAUD_DEFINED ExtBT_ReadUsartBaud(void);
BT_STATUS_TYPEDEF ExtBT_ResetPara(void);
void ExtBT_NormalMode(void);
void ExtBT_ATMode(void);
void Num2String(u32 num,u8 *str);
BT_STATUS_TYPEDEF ExtBT_Config(u8 *name,u8 *mode,u8 *pswd);
u8 ExtBT_Init(void);
u16 ReadExtBTData(void);
void SendExtBTData(u8 data);



#endif