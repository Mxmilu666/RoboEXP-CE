#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetMotorCode.h>
#include <SetMotor.h>
#include <GetMotorCode.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    unsigned int var0 = 0;
    SetMotorCode(_M1_);
    while (1)
    {
        SetMotor(_M1_, 50);
        var0 = GetMotorCode(_M1_);
        SetDisplayVar(1, var0, YELLOW, BLACK);
    }
    while(1);
}

