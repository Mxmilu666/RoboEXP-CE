#include "HardwareInfo.c"
#include <GetSysTime.h>
#include <SetDisplayVar.h>
#include <SetSysTime.h>

int main(void)
{
    E3RCU_Init();
    unsigned int var0 = 0;
    while (1)
    {
        var0 = GetSysTime();
        SetDisplayVar(1, var0, YELLOW, BLACK);
        if ( var0>10000 )
        {
            SetSysTime();
        }
    }
    while(1);
}

