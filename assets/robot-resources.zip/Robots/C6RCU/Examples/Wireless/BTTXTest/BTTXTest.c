#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetBluetoothData.h>
#include <SetWaitForTime.h>

int main(void)
{
    C6RCU_Init();
    SetDisplayString(1, "������������  10", YELLOW, BLACK);
    while (1)
    {
        SetBluetoothData(10);
        SetWaitForTime(1);
    }
    while(1);
}

