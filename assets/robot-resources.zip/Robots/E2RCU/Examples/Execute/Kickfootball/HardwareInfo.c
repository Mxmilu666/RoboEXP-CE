#ifndef _KICK_
#define _KICK_ unsigned long
#endif
#ifndef _KICK_1_
#define _KICK_1_ 4384
#endif
