#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include "SetIR.c"
#include "GetIRDete.c"

int main(void)
{
    E6RCU_Init();
    int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1:Send", YELLOW, BLACK);
    SetDisplayString(2, "P2:Receive", YELLOW, BLACK);
    while (1)
    {
        SetIR(_P1_, 1);
        var0 = GetIRDete(_P2_);
        if ( var0>0 )
        {
            SetDisplayString(3, "YES", YELLOW, BLACK);
        }
        else
        {
            SetDisplayString(3, "NO ", YELLOW, BLACK);
        }
    }
    while(1);
}

