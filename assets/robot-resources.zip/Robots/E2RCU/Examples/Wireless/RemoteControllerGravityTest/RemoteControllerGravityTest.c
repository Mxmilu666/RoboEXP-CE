#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetRemoteControllerGravity.h>
#include <SetDisplayVar.h>

int main(void)
{
    E2RCU_Init();
    int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "Remote Controller", YELLOW, BLACK);
    SetDisplayString(2, "Gravity", YELLOW, BLACK);
    SetDisplayString(3, "gx:", YELLOW, BLACK);
    SetDisplayString(4, "gy:", YELLOW, BLACK);
    SetDisplayString(5, "gz:", YELLOW, BLACK);
    while (1)
    {
        var0 = GetRemoteControllerGravity(1);
        SetDisplayVar(3, var0, YELLOW, BLACK);
        var0 = GetRemoteControllerGravity(2);
        SetDisplayVar(4, var0, YELLOW, BLACK);
        var0 = GetRemoteControllerGravity(3);
        SetDisplayVar(5, var0, YELLOW, BLACK);
    }
    return 1;
}

