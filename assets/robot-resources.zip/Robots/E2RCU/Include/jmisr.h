#ifndef _JMDISR_
#define _JMDISR_

#include <jmkernel32.h>

//�û�������־λ,��־λΪ1��ִ���жϺ���
//�жϺ������������ɶ���,�����жϺ���Ҫ����ȫ����
//�����жϺ�����CreateUserFuntionISR(pUserFun,irqn)
//pUserFun:�û��Զ����жϺ�����,���Ҳ����в����ͷ���ֵ
//����:�жϺ�����ΪMyFun������Ҫ��ȫ�������庯����void MyFun(void) {}
//irqn:�ж�����,��ϸ�ж���������jmkernel32.h�ж�������
//ע��CreateUserFuntionISR�����жϳ�ʼ��,�������жϺ���
extern u8 g_UserISRsr[];
//�޸����º궨�忪���û��жϺ���
//#define _TIM1_UP_ISR_
//#define _TIM2_ISR_
//#define _TIM8_UP_ISR_
//#define _TIM8_TRG_ISR_
//#define _TIM8_COM_ISR_
//#define _EXTI0_ISR_
//#define _EXTI1_ISR_
//#define _EXTI2_ISR_
//#define _EXTI3_ISR_
//#define _EXTI4_ISR_
//#define _EXTI10_ISR_
//#define _EXTI11_ISR_
//#define _EXTI12_ISR_
//#define _EXTI13_ISR_
//#define _EXTI14_ISR_
//#define _EXTI15_ISR_
//�ѿ��ŵ��жϺ���
void TIM1_UP_ISR(void)
{
#ifdef _TIM1_UP_ISR_
	if(TIM_GetITStatus(TIM1, TIM_FLAG_Update)==SET)
	{
		TIM_ClearITPendingBit(TIM1, TIM_FLAG_Update);
		if(g_UserISRsr[TIM1UPIRQ])//�û��Զ����жϺ���
		{
			//User_ISR(TIM1UPIRQ);
			UserISR_TIM1Up();
		}
		else
		{//
		}
		
	}
#endif
}
void TIM2_ISR(void)
{
#ifdef _TIM2_ISR_
	if(TIM_GetITStatus(TIM2, TIM_FLAG_Update)==SET)
	{
		TIM_ClearITPendingBit(TIM2, TIM_FLAG_Update);
		if(g_UserISRsr[TIM2IRQ])
		{
			//User_ISR(TIM2IRQ);
			UserISR_TIM2();
		}
		else
		{//
		}
	}
#endif
}
void TIM8_UP_ISR(void)
{
#ifdef _TIM8_UP_ISR_
	if(TIM_GetITStatus(TIM8, TIM_FLAG_Update)==SET)
	{
		TIM_ClearITPendingBit(TIM8, TIM_FLAG_Update);
		if(g_UserISRsr[TIM8UPIRQ])
		{
			//User_ISR(TIM8UPIRQ);
			UserISR_TIM8Up();
		}
		else
		{//
		}
	}
#endif
}
void TIM8_TRG_COM_ISR(void)
{
#ifdef _TIM8_TRG_ISR_
	if(TIM_GetITStatus(TIM8, TIM_FLAG_Trigger)==SET)
	{
		TIM_ClearITPendingBit(TIM8, TIM_FLAG_Trigger);
		if(g_UserISRsr[TIM8TRGIRQ])
		{
			//User_ISR(TIM8TRGIRQ);
			UserISR_TIM8Trg();
		}
		else
		{//
		}
	}
#endif
#ifdef _TIM8_COM_ISR_
	if(TIM_GetITStatus(TIM8, TIM_FLAG_COM)==SET)
	{
		TIM_ClearITPendingBit(TIM8, TIM_FLAG_COM);
		if(g_UserISRsr[TIM8COMIRQ])
		{
			//User_ISR(TIM8COMIRQ);
			UserISR_TIM8Com();
		}
		else
		{//
		}
	}
#endif
}
void EXTI0_ISR(void)
{
#ifdef _EXTI0_ISR_
	if(EXTI_GetITStatus(EXTI_Line0) != RESET)
    {
		if(g_UserISRsr[EXTI0IRQ])
		{
			//User_ISR(EXTI0IRQ);
			UserISR_Exti0();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line0);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line0);          //����жϱ�־�����룩
	}
#endif
}
void EXTI1_ISR(void)
{
#ifdef _EXTI1_ISR_
	if(EXTI_GetITStatus(EXTI_Line1) != RESET)
    {
		if(g_UserISRsr[EXTI1IRQ])
		{
			//User_ISR(EXTI1IRQ);
			UserISR_Exti1();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line1);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line1);          //����жϱ�־�����룩
	}
#endif
}
void EXTI2_ISR(void)
{
#ifdef _EXTI2_ISR_
	if(EXTI_GetITStatus(EXTI_Line2) != RESET)
    {
		if(g_UserISRsr[EXTI2IRQ])
		{
			//User_ISR(EXTI2IRQ);
			UserISR_Exti2();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line2);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line2);          //����жϱ�־�����룩
	}
#endif
}
void EXTI3_ISR(void)
{
#ifdef _EXTI3_ISR_
	if(EXTI_GetITStatus(EXTI_Line3) != RESET)
    {
		if(g_UserISRsr[EXTI3IRQ])
		{
			//User_ISR(EXTI3IRQ);
			UserISR_Exti3();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line3);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line3);          //����жϱ�־�����룩
	}
#endif
}
void EXTI4_ISR(void)
{
#ifdef _EXTI4_ISR_
	if(EXTI_GetITStatus(EXTI_Line4) != RESET)
    {
		if(g_UserISRsr[EXTI4IRQ])
		{
			//User_ISR(EXTI4IRQ);
			UserISR_Exti4();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line4);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line4);          //����жϱ�־�����룩
	}
#endif
}
void EXTI15_10_ISR(void)
{
#ifdef _EXTI10_ISR_
	if(EXTI_GetITStatus(EXTI_Line10) != RESET)
    {
		if(g_UserISRsr[EXTI10IRQ])
		{
			//User_ISR(EXTI10IRQ);
			UserISR_Exti10();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line10);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line10);          //����жϱ�־�����룩
	}
#endif
#ifdef _EXTI11_ISR_
	if(EXTI_GetITStatus(EXTI_Line11) != RESET)
    {
		if(g_UserISRsr[EXTI11IRQ])
		{
			//User_ISR(EXTI11IRQ);
			UserISR_Exti11();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line11);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line11);          //����жϱ�־�����룩
	}
#endif
#ifdef _EXTI12_ISR_
	if(EXTI_GetITStatus(EXTI_Line12) != RESET)
    {
		if(g_UserISRsr[EXTI12IRQ])
		{
			//User_ISR(EXTI12IRQ);
			UserISR_Exti12();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line12);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line12);          //����жϱ�־�����룩
	}
#endif
#ifdef _EXTI13_ISR_
	if(EXTI_GetITStatus(EXTI_Line13) != RESET)
    {
		if(g_UserISRsr[EXTI13IRQ])
		{
			//User_ISR(EXTI13IRQ);
			UserISR_Exti13();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line13);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line13);          //����жϱ�־�����룩
	}
#endif
#ifdef _EXTI14_ISR_
	if(EXTI_GetITStatus(EXTI_Line14) != RESET)
    {
		if(g_UserISRsr[EXTI14IRQ])
		{
			//User_ISR(EXTI14IRQ);
			UserISR_Exti14();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line14);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line14);          //����жϱ�־�����룩
	}
#endif
#ifdef _EXTI15_ISR_
	if(EXTI_GetITStatus(EXTI_Line15) != RESET)
    {
		if(g_UserISRsr[EXTI15IRQ])
		{
			//User_ISR(EXTI15IRQ);
			UserISR_Exti15();
		}
		else
		{//
		}
		EXTI_ClearITPendingBit(EXTI_Line15);   // Clear the Key Button EXTI line pending bit 
		EXTI_ClearFlag(EXTI_Line15);          //����жϱ�־�����룩
	}
#endif
}

#endif