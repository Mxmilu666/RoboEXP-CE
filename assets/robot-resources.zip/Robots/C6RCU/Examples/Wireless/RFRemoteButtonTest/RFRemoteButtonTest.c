#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <SetRFPassWord.h>
#include <GetRFModuleRemoteButton.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    unsigned int var1 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Remote Button", YELLOW, BLACK);
    SetRFPassWord(_P1_, 1234567);
    while (1)
    {
        var1 = GetRFModuleRemoteButton(_P1_);
        SetDisplayVar(2, var1, YELLOW, BLACK);
    }
    while(1);
}

