#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetCompassB.h>
#include <SetDisplayVar.h>

int main(void)
{
    E2RCU_Init();
    unsigned int degree = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Compass", YELLOW, BLACK);
    while (1)
    {
        degree = GetCompassB(_P1_);
        SetDisplayVar(3, degree, YELLOW, BLACK);
    }
    while(1);
}

