#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <GetScanCamera.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    SetDisplayString(1, "��ά�����", YELLOW, BLACK);
    while (1)
    {
        var0 = GetScanCamera();
        if ( var0!=999 )
        {
            SetDisplayVar(1, var0, YELLOW, BLACK);
        }
    }
    while(1);
}

