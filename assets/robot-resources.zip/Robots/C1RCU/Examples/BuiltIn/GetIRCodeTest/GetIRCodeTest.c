#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetIRCode.h>
#include <Set3CLed.h>
#include <SetWaitForTime.h>

int main(void)
{
   C1RCU_Init();
    long var0 = 0;
    while (1)
    {
        var0 = GetIRCode();
        if ( var0==12 )
        {
            Set3CLed(_RGB1_, RED);
        }
        else
        {
            if ( var0==24 )
            {
                Set3CLed(_RGB1_, GREEN);
            }
            else
            {
                if ( var0==94 )
                {
                    Set3CLed(_RGB1_, BLUE);
                }
            }
        }
        SetWaitForTime(0.1);
    }
    while(1);
}

