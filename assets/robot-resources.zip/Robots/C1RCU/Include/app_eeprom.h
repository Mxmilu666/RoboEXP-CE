/*
********************************************************************************
* Filename      : app_eeprom.h
* Version       : V1.00
* Programmer(s) : qiezhihuai
********************************************************************************
*/
 
#ifndef _APP_EEPROM_H
#define _APP_EEPROM_H
 
#ifdef __cplusplus
	extern "C"{
#endif
 
 
		
#include "emulation_ee.h"
 
 
/* 虚拟地址宏 */
/* ee init flag,if value = 0 or 0xffff do init virtAddVarTab,else if don't init */
#define	EE_READ_STATUS_VIRT_ADDR		virt_add_var_tab[0]	        /* 第一次上电初始化标识，0表示成功初始化完成，1表示没有进行过初始化 */
#define	TEMP_EE_ADDR					virt_add_var_tab[1]         /* 虚拟地址1中存储的是 温度数据 */
 
/* 初始化API */
void app_ee_init(void);
void EepAdr_Init(void);

uint16_t ReadEEP(uint16_t address);
void WriteEEP(uint16_t address,uint16_t data);
 
#ifdef __cplusplus
	}
#endif
	
#endif
