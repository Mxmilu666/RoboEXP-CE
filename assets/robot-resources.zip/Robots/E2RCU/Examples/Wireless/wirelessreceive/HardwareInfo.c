#ifndef _WIRELESS_
#define _WIRELESS_ unsigned long
#endif
#ifndef _WIRELESSRXD_
#define _WIRELESSRXD_ unsigned long
#endif
#ifndef _WIRELESS_1_
#define _WIRELESS_1_ 6320
#endif
#ifndef _WIRELESSRXD_1_
#define _WIRELESSRXD_1_ 4384
#endif
