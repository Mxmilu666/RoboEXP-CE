#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetUltrasound.h>
#include <SetRGB.h>

int main(void)
{
   C1RCU_Init();
    long var0 = 0;
    while (1)
    {
        var0 = GetUltrasound(_P1_);
        if ( var0<6 )
        {
            SetRGB(0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000);
        }
        else
        {
            SetRGB(0, 0, 0, 0, 0);
        }
    }
    while(1);
}

