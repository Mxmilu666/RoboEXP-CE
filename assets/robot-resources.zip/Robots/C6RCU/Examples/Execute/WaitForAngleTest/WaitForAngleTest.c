#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetWaitForAngle.h>
#include <SetWaitForTime.h>

int main(void)
{
    C6RCU_Init();
    while (1)
    {
        SetWaitForAngle(_M1_, 50, 90);
        SetWaitForTime(1);
        SetWaitForAngle(_M1_, -50, 90);
        SetWaitForTime(1);
    }
    while(1);
}

