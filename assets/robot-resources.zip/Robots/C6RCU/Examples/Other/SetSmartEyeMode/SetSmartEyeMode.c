#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetSmartEyeMode2.h>
#include <SetWaitForTime.h>

int main(void)
{
    C6RCU_Init();
    SetDisplayString(1, "�ǻ��۲ʵƲ���", YELLOW, BLACK);
    while (1)
    {
        SetSmartEyeMode2(_P1_, 1, "100100100");
        SetWaitForTime(3.5);
        SetSmartEyeMode2(_P1_, 2, "000000100");
        SetWaitForTime(3);
    }
    while(1);
}

