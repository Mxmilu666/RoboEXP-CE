#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <GetBluetoothData.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    SetDisplayString(1, "������������", YELLOW, BLACK);
    while (1)
    {
        var0 = GetBluetoothData();
        SetDisplayVar(1, var0, YELLOW, BLACK);
    }
    while(1);
}

