#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetSmartEyeAllLed2.h>
#include <SetWaitForTime.h>

int main(void)
{
    C6RCU_Init();
    SetDisplayString(1, "�ǻ��۲ʵƲ���", YELLOW, BLACK);
    while (1)
    {
        SetSmartEyeAllLed2(_P1_, "100000000", "100000000", "100000000", "100000000", "100000000", "100000000", "100000000", "100000000");
        SetWaitForTime(1);
        SetSmartEyeAllLed2(_P1_, "000100000", "000100000", "000100000", "000100000", "000100000", "000100000", "000100000", "000100000");
        SetWaitForTime(1);
        SetSmartEyeAllLed2(_P1_, "000000100", "000000100", "000000100", "000000100", "000000100", "000000100", "000000100", "000000100");
        SetWaitForTime(1);
    }
    while(1);
}

