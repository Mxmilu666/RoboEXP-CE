#ifndef   _JMKERNEL32_H_
#define  _JMKERNEL32_H_

#include "stm32f10x_lib.h"

typedef char* string;
//����ղ���,ͳһMDK��GCC
#if defined (KEIL)//
#define _NOP()	__nop
#elif defined (IAR)
#define _NOP()	asm("NOP")
#else //GCC
#define _NOP()	asm("nop")
#endif

#define USERRUN_ADDRESS	0x08031000
#define WLHID_ADDRESS			0x08041000

#define _TOUCH_TO_SCREEN_EN_ 1u//��Ļת��ʹ�ܿ���
vu8 g_MotorPowerFlag=0;
vu8 g_M1SpeedPer=100,g_M2SpeedPer=100,g_M3SpeedPer=100,g_M4SpeedPer=100;//��������������ٶȵİٷֱ�
vu8 g_LcdBackLignt=1;//Ĭ�ϱ������
//#define SetBackLed(led) {if (led)	GPIO_SetBits(GPIOA,GPIO_Pin_4); else     GPIO_ResetBits(GPIOA,GPIO_Pin_4);}
//�û��ж�������
#define USERISR_IRQ_SIZE	16//�ж���������
typedef enum
{
	TIM1UPIRQ,	//0
	TIM2IRQ,	//1
	TIM8UPIRQ,	//2
	TIM8TRGIRQ,	//3
	TIM8COMIRQ,	//4
	EXTI0IRQ,	//5
	EXTI1IRQ,	//6
	EXTI2IRQ,	//7
	EXTI3IRQ,	//8
	EXTI4IRQ,	//9
	EXTI10IRQ,	//10
	EXTI11IRQ,	//11
	EXTI12IRQ,	//12
	EXTI13IRQ,	//13
	EXTI14IRQ,	//14
	EXTI15IRQ	//15
}USERFUNTON_DEFINED;


typedef void (*pUserFunction)(void);//�û�����ָ��

void E2RCU_Init(void);
void GPIO_Setting(GPIO_TypeDef* port,u8 pin,u8 mode);
void BeepInit(void);
void Beep(u8 state);
u8 ADC_Configuration(u32 SimpleTime) ;
u16 GetAdcResult(u8 channel);
void EepAdr_Init(void);
u16 ReadEEP(u16 address);
void WriteEEP(u16 address,u16 data);
u8  SystemTime_init(void);
void SetSystemTime(void);
u32 GetSystemTime(void);
void delayTenthms(u32 Tenthms);
void Delay1ms(u32 ms);
u16 ReadMotorDir(u8 ch);
u8 Motor_Init(void);
void SetMotorX(u8 MotorX,u8 Dir,u8 Speed);
u8 MotorCodingInit(void);
void SetMotorServoMode(u8 MotorX);
void SetMotorNormalMode(u8 MotorX);
void MotorCoding_Istr(void);
void SetMotorCnt1Zero(void);
void SetMotorCnt2Zero(void);
void SetMotorCnt3Zero(void);
void SetMotorCnt4Zero(void);
vs32 GetMotorCnt1(void);
vs32 GetMotorCnt2(void);
vs32 GetMotorCnt3(void);
vs32 GetMotorCnt4(void);
void SetCodeServoAngle48(u8 MotorX,u8 speed,u32 Angle);
u8 GetTouchValid(void);
u16 GetTouchY(void);
u16 GetTouchX(void);
#endif