#ifndef _JMDTRACE_H_
#define _JMDTRACE_H_
//#include "lcd320240.h"
//#include "stm32f4xx_hal.h"
//#include "stm32f4xx.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "I2C_Soft.h"
#include "jmkernel.h"
#include "Pinformat.h"

#define uint32_t unsigned int

typedef unsigned char uint8_t;
typedef unsigned short uint16_t;


/************************************内置函数*************************************************/

/****************************************Track*************************************************************/
static volatile uint8_t trace_line_color = 0;
static volatile uint8_t trace_line_which = 1;
static volatile uint8_t trace_line_chassis_status = 0;
static volatile uint32_t trace_line_00 = 0;
static volatile uint8_t trace_line_t2 = 0;

static volatile uint32_t trace_line_tt = 0;


static volatile uint8_t trace_line_t3 = 0;

static volatile int32_t trace_line_tt1 = 0;
static volatile uint8_t trace_line_t4 = 0;
static volatile int32_t trace_line_zz = 0;
static volatile uint32_t trace_line_t26 = 0;
static volatile uint8_t trace_line_t5 = 0;
static volatile int32_t trace_line_temp = 0;
static volatile uint8_t trace_line_t6 = 0;
static volatile uint8_t trace_line_t1 = 0;
static volatile uint8_t trace_line_t7 = 0;
/****************************************Track*************************************************************/

void trace_Line_Intersection_Stop(int32_t speedu,int32_t which);
void trace_Line_Basis(int8_t speedup);
void trace_Line_Millisecond(int8_t speed, int32_t time);
void trace_Line_Get_State();
void trace_Line_Forward_For_Bmp(int32_t sp,int32_t bmp);
void trace_Line_Turn_Encounterline(int32_t spl,int32_t spr,int32_t whi);
void trace_Line_For_Bmp(int32_t sp0,int32_t bmp);
void trace_Turn_For_Bmp(int32_t sp,int32_t bmp);


static uint8_t Get_Trace_V2I2CState( uint8_t which, uint8_t bit)
{
	uint32_t port1=portarray[RcuPORT[which][0]];//I2C_SCL
	uint32_t port2=portarray[RcuPORT[which][1]];//I2C_SDA
	uint8_t bit1=RcuPIN[which][0];
	uint8_t bit2=RcuPIN[which][1];

	uint8_t m_ChannelState;
   //OS_ENTER_CRITICAL();

	// RcuWhichMutexTake(which,1,0XFFFF);//获取�?�?IIC使用�?
    Soft_I2C_Typedef iic_typedef;
	Soft_I2C_BspInit(port2,bit2,//SDA
                    port1,bit1,//SCL
										&iic_typedef);

    Soft_I2C_Start(&iic_typedef);
    Soft_I2C_Write(&iic_typedef,TRACE_ADDR);
    Soft_I2C_Write(&iic_typedef,Set_Encryp(9));
    Soft_I2C_Stop(&iic_typedef);
    
    Soft_I2C_Start(&iic_typedef);
    Soft_I2C_Write(&iic_typedef,TRACE_ADDR+1);
    m_ChannelState=Get_Decry(Soft_I2C_Read(&iic_typedef,1));
    Soft_I2C_Stop(&iic_typedef);

	m_ChannelState = m_ChannelState   &   (0x01   <<   (bit-1))   ?   1   :   0;
	if(TraceLineColor[which-1] == 0)
	 	m_ChannelState = m_ChannelState;
	else 
		m_ChannelState = (!m_ChannelState);
	return m_ChannelState;
}

/*初�?��?�置�?迹卡�?口，巡线颜色，底盘�?�色*/
void trace_Line_Set_Initialize(uint8_t which,char * temp_color,char * temp_chassis)
{
	// char temp_color[20] = {0};
	// char temp_chassis[20] = {0};
	
	trace_line_which = which;
    if (strcmp(temp_color,"black") == 0){
        trace_line_color = 0;
    }
    if (strcmp(temp_color,"white") == 0){
        trace_line_color = 1;
    }
    if (strcmp(temp_chassis,"wheeledchassis") == 0){
        trace_line_chassis_status = 0;
    }
	
    if (strcmp(temp_chassis,"mecanumchassis") == 0){
        trace_line_chassis_status = 1;
    }
	// LCD_DisplayNum(10, 10,(int32_t)trace_line_chassis_status, 0xFFE0, 0x0000,0x8088); 
	return;
}

/*定义左速度和右速度*/
void trace_Line_Speed_Control(int32_t speedl,int32_t speedr)
{
	if (trace_line_chassis_status == 0){
        Set_Motor_X(1,speedl);
        Set_Motor_X(2,speedr);
    } else {
        if (trace_line_chassis_status == 1){
            Set_Motor_X(1,speedl);
            Set_Motor_X(2,speedr);
            Set_Motor_X(3,speedl);
            Set_Motor_X(4,speedr);
        }
    }
	return;
}




/*遇线停�??*/
void trace_Line_Intersection_Stop(int32_t speedu,int32_t which)
{
	//LCD_DisplayNum(10, 30,(int32_t)which, 0xFFE0, 0x0000,0x8088); 
    trace_Line_For_Bmp(40,100);
    trace_Line_Speed_Control(speedu,speedu);
    if (which == 17){
        while (!((trace_line_t1 == 1) && (trace_line_t7 == 1))){
            trace_Line_Basis(speedu);
        }
    } else {
        if (which == 1){
            while (!(trace_line_t1 == 1)){
                trace_Line_Basis(speedu);
            }
        } else {
            while (!(trace_line_t7 == 1)){
                trace_Line_Basis(speedu);
            }
        }
    }
   //LCD_DisplayNum(10, 30,(int32_t)2, 0xFFE0, 0x0000,0x8088); 
	SetMusicPWMFreq(2700);


    Delay1ms(10);
    SetMusicPWMFreq(0);
    trace_Line_Speed_Control(0,0);
	return ;
}

/*以基础速度巡线一�?*/
void trace_Line_Basis(int8_t speedup)
{
    trace_Line_Get_State();
    trace_line_00 = (uint32_t)GetSystemTime();
    if (trace_line_t2 == 1){
        trace_Line_Speed_Control(-20,50);
        trace_line_t26 = (uint32_t)GetSystemTime();
        trace_line_temp = 1;
    } else {
        if (trace_line_t6 == 1){
            trace_Line_Speed_Control(50,-20);
            trace_line_t26 = (uint32_t)GetSystemTime();
            trace_line_temp = 5;
        } else {
            if (trace_line_t3 == 1){
                trace_Line_Speed_Control((speedup * 0.6),(speedup * 1));
                if ((trace_line_00 - trace_line_t26) > 200){
                    trace_line_temp = 2;
                }
            } else {
                if (trace_line_t5 == 1){
                    trace_Line_Speed_Control((speedup * 1),(speedup * 0.6));
                    if ((trace_line_00 - trace_line_t26) > 200){
                        trace_line_temp = 4;
                    }
                } else {
                    if (trace_line_t4 == 1){
                        trace_Line_Speed_Control((speedup * 1),(speedup * 1));
                        if ((trace_line_00 - trace_line_t26) > 200){
                            trace_line_temp = 3;
                        }
                    } else {
                        if ((trace_line_t2 == 0) && ((trace_line_t3 == 0) && ((trace_line_t4 == 0) && ((trace_line_t5 == 0) && (trace_line_t6 == 0))))){
                            if (trace_line_temp == 1){
                                trace_Line_Speed_Control(-50,50);
                            }
                            if (trace_line_temp == 2){
                                trace_Line_Speed_Control((speedup * 0.6),(speedup * 1));
                            }
                            if (trace_line_temp == 3){
                                trace_Line_Speed_Control((speedup * 1),(speedup * 1));
                            }
                            if (trace_line_temp == 4){
                                trace_Line_Speed_Control((speedup * 1),(speedup * 0.6));
                            }
                            if (trace_line_temp == 5){
                                trace_Line_Speed_Control(50,-50);
                            }
                        } else {
                            trace_Line_Speed_Control((speedup * 1),(speedup * 1));
                        }
                    }
                }
            }
        }
    }
	return ;
}
/*巡线时间*/
void trace_Line_Millisecond(int8_t speed, int32_t time)
{
    trace_line_tt = (uint32_t)GetSystemTime();
    while (!(( ((uint32_t)GetSystemTime()) - trace_line_tt) > time)){
        trace_Line_Basis(speed);
    }
    trace_Line_Speed_Control(0,0);
}

/*读取光电�?*/
void trace_Line_Get_State()
{
    if (trace_line_color == 0){
        trace_line_t2 = Get_Trace_V2I2CState(trace_line_which,2);
        trace_line_t3 = Get_Trace_V2I2CState(trace_line_which,3);
        trace_line_t4 = Get_Trace_V2I2CState(trace_line_which,4);
        trace_line_t5 = Get_Trace_V2I2CState(trace_line_which,5);
        trace_line_t6 = Get_Trace_V2I2CState(trace_line_which,6);
        trace_line_t1 = Get_Trace_V2I2CState(trace_line_which,1);
        trace_line_t7 = Get_Trace_V2I2CState(trace_line_which,7);
    } else {
        if (trace_line_color == 1){
            trace_line_t2 = !((Get_Trace_V2I2CState(trace_line_which,2)));
            trace_line_t3 = !((Get_Trace_V2I2CState(trace_line_which,3)));
            trace_line_t4 = !((Get_Trace_V2I2CState(trace_line_which,4)));
            trace_line_t5 = !((Get_Trace_V2I2CState(trace_line_which,5)));
            trace_line_t6 = !((Get_Trace_V2I2CState(trace_line_which,6)));
            trace_line_t1 = !((Get_Trace_V2I2CState(trace_line_which,1)));
            trace_line_t7 = !((Get_Trace_V2I2CState(trace_line_which,7)));
        }
    }
}


/*设置编码前进速度*/
void trace_Line_Forward_For_Bmp(int32_t sp,int32_t bmp)
{
    Set_Motor_Code(1);
    trace_Line_Speed_Control(sp,sp);
    trace_line_tt = Get_Motor_Code(1);
    trace_line_zz = Get_Motor_Code(1);
	
    while (!((trace_line_zz - trace_line_tt) > bmp)){
        trace_line_zz = Get_Motor_Code(1);
        if (trace_line_zz < 0){
            trace_line_zz = (0 - trace_line_zz);
        }

    }
    trace_Line_Speed_Control(0,0);
}
/*�?�?遇线*/
void trace_Line_Turn_Encounterline(int32_t spl,int32_t spr,int32_t whi)
{
    trace_Line_Speed_Control(spl,spr);
    // trace_line_tt = (uint32_t)GetSystemTime();
    // while (!(( ((uint32_t)GetSystemTime()) - trace_line_tt) > 200)){
    // }
    Delay1ms(300);
    trace_Line_Get_State();
    if (whi == 1){
        while (!(trace_line_t2 == 1)){
            trace_Line_Get_State();
        }
    } else {
        if (whi == 2){
            while (!(trace_line_t3 == 1)){
                trace_Line_Get_State();
            }
        } else {
            if (whi == 3){
                while (!(trace_line_t4 == 1)){
                    trace_Line_Get_State();
                }
            } else {
                if (whi == 4){
                    while (!(trace_line_t5 == 1)){
                        trace_Line_Get_State();
                    }
                } else {
                    if (whi == 5){
                        while (!(trace_line_t6 == 1)){
                            trace_Line_Get_State();
                        }
                    } else {
                    }
                }
            }
        }
    }
    trace_Line_Speed_Control(0,0);
}
/*巡线编码*/
void trace_Line_For_Bmp(int32_t sp0,int32_t bmp)
{
    Set_Motor_Code(1);
    trace_line_tt = Get_Motor_Code(1);
    trace_line_tt1 = Get_Motor_Code(2);
    trace_line_zz = Get_Motor_Code(1);
    // while (!((trace_line_zz - trace_line_tt) > bmp)){
    //     trace_Line_Basis(sp0);
    //     trace_line_zz = Get_Motor_Code(1);
    //     if (trace_line_zz < 0){
    //         trace_line_zz = (0 - trace_line_zz);
    //     }
    // }
	
    trace_Line_Speed_Control(0,0);
}
/*编码�?�?*/
void trace_Turn_For_Bmp(int32_t sp,int32_t bmp)
{
    trace_Line_Speed_Control(sp,(-1 * sp));
    Set_Motor_Code(1);
	
    trace_line_tt = Get_Motor_Code(1);
    trace_line_zz = Get_Motor_Code(1);

    while (!((trace_line_zz - trace_line_tt) > bmp)){
        trace_line_zz = Get_Motor_Code(1);
		//LCD_DisplayNum(10, 50,(int32_t)trace_line_zz, 0xFFE0, 0x0000,0x8088); 
        if (trace_line_zz < 0){
            trace_line_zz = (0 - trace_line_zz);
        }
    }
    trace_Line_Speed_Control(0,0);
}




#endif // JMDMQTT_H

