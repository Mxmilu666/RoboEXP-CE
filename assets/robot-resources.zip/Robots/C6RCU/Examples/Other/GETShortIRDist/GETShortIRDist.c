#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <GetShortIRDist.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "������", YELLOW, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        var0 = GetShortIRDist(_P1_);
        SetDisplayVar(2, var0, YELLOW, BLACK);
    }
    while(1);
}

