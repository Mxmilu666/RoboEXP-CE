#ifndef _WIRELESS_
#define _WIRELESS_ unsigned long
#endif
#ifndef _WIRELESS_1_
#define _WIRELESS_1_ 117904
#endif
