#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <SetWaitForTime.h>
#include <GetRightButton.h>
#include <SetMusicPlayer.h>
#include <SetDisplayVar.h>
#include <GetLeftButton.h>

int main(void)
{
    C6RCU_Init();
    int b1 = 0;
    int b2 = 0;
    unsigned char cmd = 1;
    unsigned char var0 = 1;
    int var1 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Music Player", YELLOW, BLACK);
    SetWaitForTime(0.3);
    while (1)
    {
        var1 = GetRightButton();
        if ( b1 )
        {
            SetMusicPlayer(_P1_, 85);
            SetWaitForTime(0.05);
            SetMusicPlayer(_P1_, cmd);
            var0=cmd-10;
            SetDisplayVar(2, var0, YELLOW, BLACK);
        }
        b2 = GetLeftButton();
        if ( b2==1 )
        {
            if ( cmd<4&&cmd>=1 )
            {
                cmd+=1;
            }
            else
            {
                cmd=1;
            }
        }
        SetDisplayVar(3, cmd, YELLOW, BLACK);
        SetWaitForTime(0.2);
    }
    while(1);
}

