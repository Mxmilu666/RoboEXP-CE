#include "HardwareInfo.c"
#include "JMLib.c"
#include <Charge.h>
#include <SetNS.h>
#include <Kickfootball.h>

int main(void)
{
    X1RCU_Init();
    Charge(_KICK_1_);
    while (1)
    {
        SetNS(5);
        Kickfootball(_KICK_1_, 0);
        SetNS(5);
        Kickfootball(_KICK_1_, 1);
    }
    return 1;
}

