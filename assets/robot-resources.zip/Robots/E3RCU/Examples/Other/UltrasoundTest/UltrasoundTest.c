#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <GetUltrasound.h>
#include <SetDisplayVar.h>

int main(void)
{
    E3RCU_Init();
    int var0 = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Ultrasound", YELLOW, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        var0 = GetUltrasound(_P1_, 0);
        SetDisplayVar(1, var0, YELLOW, BLACK);
        var0 = GetUltrasound(_P1_, 1);
        SetDisplayVar(2, var0, YELLOW, BLACK);
    }
    while(1);
}

