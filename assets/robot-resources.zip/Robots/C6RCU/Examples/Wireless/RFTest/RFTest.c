#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <SetRFPassWord.h>
#include <SetRFModuleByte.h>
#include <SetDisplayVar.h>
#include <GetRFModuleByte.h>

int main(void)
{
    C6RCU_Init();
    unsigned int state = 0;
    unsigned char TX = 0;
    unsigned int RX = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "Transmit(P1):", YELLOW, BLACK);
    SetDisplayString(4, "Receive(P2):", YELLOW, BLACK);
    SetRFPassWord(_P1_, 1234567);
    SetRFPassWord(_P2_, 1234567);
    while (1)
    {
        state = SetRFModuleByte(_P1_, TX);
        SetDisplayVar(1, TX, YELLOW, BLACK);
        TX=TX+1;
        RX = GetRFModuleByte(_P2_);
        SetDisplayVar(4, RX, YELLOW, BLACK);
    }
    while(1);
}

