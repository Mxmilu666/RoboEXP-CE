#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetDisplayVar.h>
#include <SetLCDBack.h>
#include <GetGesture.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "���Ƽ��", YELLOW, BLACK);
    SetDisplayVar(1, var0, YELLOW, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        var0 = GetGesture(_P1_);
        if ( var0!=0 )
        {
            SetDisplayVar(1, var0, YELLOW, BLACK);
        }
    }
    while(1);
}

