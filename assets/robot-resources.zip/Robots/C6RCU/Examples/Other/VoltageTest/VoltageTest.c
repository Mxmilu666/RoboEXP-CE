#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <GetVoltage.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    C6RCU_Init();
    unsigned int var0 = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Voltage", YELLOW, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        var0 = GetVoltage(_P1_);
        SetDisplayVar(3, var0, YELLOW, BLACK);
        SetWaitForTime(0.2);
    }
    while(1);
}

