#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetFontSize.h>
#include <SetDisplayString.h>
#include <SetWifiUdpMode.h>
#include <GetWifiData.h>
#include <SetDisplayVar.h>

int main(void)
{
    E3RCU_Init();
    unsigned int var0 = 0;
    SetLCDBack(1);
    SetFontSize(1);
    SetDisplayString(1, "WIFI Receive:", YELLOW, BLACK);
    SetWifiUdpMode("192.168.0.100", 8080, 8080);
    while (1)
    {
        var0 = GetWifiData();
        if ( var0<256 )
        {
            SetDisplayVar(2, var0, YELLOW, BLACK);
        }
    }
    while(1);
}

