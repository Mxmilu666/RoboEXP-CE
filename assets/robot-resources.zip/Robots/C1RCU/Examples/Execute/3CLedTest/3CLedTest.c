#include "HardwareInfo.c"
#include "JMLib.c"
#include <Set3CLed.h>
#include <SetWaitForTime.h>

int main(void)
{
   C1RCU_Init();
    while (1)
    {
        Set3CLed(_RGB1_, RED);
        SetWaitForTime(1);
        Set3CLed(_RGB1_, OFF);
        SetWaitForTime(1);
        Set3CLed(_RGB1_, BLUE);
        SetWaitForTime(1);
        Set3CLed(_RGB1_, OFF);
        SetWaitForTime(1);
        Set3CLed(_RGB1_, GREEN);
        SetWaitForTime(1);
        Set3CLed(_RGB1_, OFF);
        SetWaitForTime(1);
    }
    while(1);
}

