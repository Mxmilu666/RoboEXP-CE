#ifndef _MP3_
#define _MP3_ unsigned long
#endif
#ifndef _MP3_MP3_
#define _MP3_MP3_ 428544
#endif
