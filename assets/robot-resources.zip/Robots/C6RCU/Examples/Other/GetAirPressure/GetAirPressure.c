#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetAirPressure.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    while (1)
    {
        var0 = GetAirPressure(_P1_);
        SetDisplayVar(1, var0, YELLOW, BLACK);
    }
    while(1);
}

