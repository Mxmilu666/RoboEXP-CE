#include "HardwareInfo.c"
#include <SetNS.h>
#include <SetRFIDData.h>
#include <SetLCD8Char.h>
#include <GetRFIDData.h>

int main(void)
{
    int data = 0;
    unsigned char status = 0;
    unsigned int Address = 0;
    SetNS(2);
    while (1)
    {
        status = SetRFIDData(_RFID_RFID_, 86, 1);
        SetLCD8Char(status, 1, 1);
        data = GetRFIDData(_RFID_RFID_, 1);
        SetLCD8Char(data, 1, 1);
    }
    return 1;
}

