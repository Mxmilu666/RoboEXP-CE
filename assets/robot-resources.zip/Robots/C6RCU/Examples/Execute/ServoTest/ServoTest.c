#include "HardwareInfo.c"
#include <SetServo.h>
#include "SetTenthS.c"
#include "SetNS.c"

int main(void)
{
    E3RCU_Init();
    while (1)
    {
        SetServo(_SERVO_1_, 35);
        SetTenthS(6);
        SetServo(_SERVO_1_, 90);
        SetNS(1);
        SetServo(_SERVO_1_, 145);
        SetTenthS(6);
    }
    while(1);
}

