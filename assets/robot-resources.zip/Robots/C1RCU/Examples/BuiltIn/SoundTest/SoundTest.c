#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetInMic.h>
#include <SetRGB.h>

int main(void)
{
   C1RCU_Init();
    int var0 = 0;
    while (1)
    {
        var0 = GetInMic();
        if ( var0>500 )
        {
            SetRGB(0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000);
        }
        else
        {
            SetRGB(0, 0, 0, 0, 0);
        }
    }
    while(1);
}

