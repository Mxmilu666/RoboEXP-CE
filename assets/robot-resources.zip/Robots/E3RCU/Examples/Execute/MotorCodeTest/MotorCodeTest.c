#include "HardwareInfo.c"
#include <SetMotorCode.h>
#include <SetMotor.h>
#include <GetMotorCode.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E3RCU_Init();
    unsigned int var0 = 0;
    unsigned int var1 = 0;
    SetMotorCode(_M1_);
    while (1)
    {
        SetMotor(_M1_, 50);
        var0 = GetMotorCode(_M1_);
        SetDisplayVar(1, var0, YELLOW, BLACK);
        SetWaitForTime(0.05);
    }
    while(1);
}

