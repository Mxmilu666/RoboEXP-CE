#ifndef _SERVO_
#define _SERVO_ unsigned long
#endif
#ifndef _SERVO_1_
#define _SERVO_1_ 1184
#endif
