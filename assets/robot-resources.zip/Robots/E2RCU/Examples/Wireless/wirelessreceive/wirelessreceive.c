#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <GetWireless.h>
#include <SetLCD3Char.h>
#include <SetTenthS.h>

// define global var
unsigned char data = 0;

int main(void)
{
    X1RCU_Init();
    unsigned int var0 = 0;
    SetLCDBack(1);
    while (1)
    {
        var0 = GetWireless(_WIRELESS_1_);
        if ( var0<888 )
        {
            SetLCD3Char(0, 0, var0);
        }
        else
        {
        }
        SetTenthS(3);
    }
    return 1;
}

