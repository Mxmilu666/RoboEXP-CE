#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <GetCompoI.h>
#include <SetDisplayVar.h>
#include <GetRightButton.h>
#include <GetLeftButton.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    unsigned char var0 = 0;
    unsigned char var1 = 0;
    unsigned char var2 = 0;
    unsigned int i = 1;
    unsigned int var4 = 0;
    unsigned int var3 = 0;
    SetDisplayString(1, "P1:      CHmax", YELLOW, BLACK);
    SetDisplayString(2, "         MaxValue", YELLOW, BLACK);
    SetDisplayString(18, "Modulate   ", YELLOW, BLACK);
    SetDisplayString(4, "         CH1", YELLOW, BLACK);
    SetDisplayString(6, "         CH2", YELLOW, BLACK);
    SetDisplayString(8, "         CH3", YELLOW, BLACK);
    SetDisplayString(10, "         CH4", YELLOW, BLACK);
    SetDisplayString(12, "         CH5", YELLOW, BLACK);
    SetDisplayString(14, "         CH6", YELLOW, BLACK);
    SetDisplayString(16, "         CH7", YELLOW, BLACK);
    SetLCDBack(ON);
    GetCompoI(_P1_, 14);
    while (1)
    {
        var0 = GetCompoI(_P1_, 8);
        SetDisplayVar(1, var0, YELLOW, BLACK);
        var0 = GetCompoI(_P1_, 9);
        SetDisplayVar(2, var0, YELLOW, BLACK);
        SetDisplayString(3, "-----------------------------", YELLOW, BLACK);
        i=1;var4=4;
        for (int _FOR_0_ = 0; _FOR_0_ < 7; _FOR_0_++ )
        {
            var0 = GetCompoI(_P1_, i);
            SetDisplayVar(var4, var0, YELLOW, BLACK);
            i=i+1;var4=var4+1;;
            SetDisplayString(var4, "-----------------------------", YELLOW, BLACK);
            var4=var4+1;;
        }
        var1 = GetRightButton();
        if ( var1==1 )
        {
            var2=0;var1=1;;
            GetCompoI(_P1_, 14);
            SetDisplayString(18, "Modulate   ", YELLOW, BLACK);
        }
        var2 = GetLeftButton();
        if ( var2==1 )
        {
            var2=1;var1=0;;
            GetCompoI(_P1_, 13);
            SetDisplayString(18, "UnModulate", YELLOW, BLACK);
        }
        SetWaitForTime(0.1);
    }
    while(1);
}

