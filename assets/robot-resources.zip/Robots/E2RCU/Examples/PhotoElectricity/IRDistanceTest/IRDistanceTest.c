#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetIRDist.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    unsigned int var0 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "IR Distance", YELLOW, BLACK);
    while (1)
    {
        var0 = GetIRDist(_P1_);
        SetDisplayVar(3, var0, YELLOW, BLACK);
        SetWaitForTime(0.1);
    }
    while(1);
}

