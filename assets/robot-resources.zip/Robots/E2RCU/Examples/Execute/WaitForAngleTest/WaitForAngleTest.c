#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetWaitForAngle.h>
#include <SetInBeep.h>

int main(void)
{
    E2RCU_Init();
    SetWaitForAngle(_M1_, 50, 270);
    SetInBeep(ON);
    SetWaitForAngle(_M1_, -50, 270);
    SetInBeep(OFF);
    while(1);
}

