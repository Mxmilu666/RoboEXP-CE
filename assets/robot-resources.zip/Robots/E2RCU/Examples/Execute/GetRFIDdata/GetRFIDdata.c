#include "HardwareInfo.c"
#include <SetNS.h>
#include <SetRFIDAddress.h>
#include <GetRFIDlastdata.h>
#include <SetLCD8Char.h>

int main(void)
{
    unsigned int data = 0;
    unsigned char status = 0;
    SetNS(2);
    SetRFIDAddress(_RFID_RFID_, 1);
    while (1)
    {
        data = GetRFIDlastdata(_RFID_RFID_);
        SetLCD8Char(data, 1, 1);
    }
    return 1;
}

