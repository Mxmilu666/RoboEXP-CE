#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayStr.h>
#include <GetAICamVoice.h>
#include <SetDisplayVar.h>
#include <SetMotor.h>

int main(void)
{
    E3RCU_Init();
    unsigned char cmd = 0;
    unsigned char cmd1 = 0;
    SetDisplayStr(0, 0, "AI�Ӿ�ģ����������", YELLOW, BLACK);
    SetDisplayStr(0, 20, "��˵ AI���� ����", YELLOW, BLACK);
    SetDisplayStr(0, 40, "��˵ ��ǰ�� ���� �����", YELLOW, BLACK);
    while (1)
    {
        cmd = GetAICamVoice(1025);
        SetDisplayVar(1, cmd, YELLOW, BLACK);
        cmd1 = GetAICamVoice(1027);
        SetDisplayVar(2, cmd1, YELLOW, BLACK);
        if ( cmd==1 )
        {
            SetMotor(_M1_, 50);
        }
        if ( cmd1==1 )
        {
            SetMotor(_M1_, -50);
        }
    }
    while(1);
}

