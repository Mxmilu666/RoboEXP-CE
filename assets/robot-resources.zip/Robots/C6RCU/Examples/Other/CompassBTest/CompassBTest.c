#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <GetCompassB.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    unsigned char degree = 0;
    unsigned char on = 1;
    SetLCDBack(on);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Compass", YELLOW, BLACK);
    while (1)
    {
        GetCompassB(_P1_);
        SetDisplayVar(3, degree, YELLOW, BLACK);
    }
    while(1);
}

