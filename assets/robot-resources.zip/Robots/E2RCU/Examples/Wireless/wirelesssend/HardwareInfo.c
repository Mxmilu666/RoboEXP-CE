#ifndef _WIRELESSTXD_
#define _WIRELESSTXD_ unsigned long
#endif
#ifndef _WIRELESSTXD_1_
#define _WIRELESSTXD_1_ 428544
#endif
