#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetSysTime.h>
#include <SetSysTime.h>
#include <SetRGB.h>

int main(void)
{
   C1RCU_Init();
    unsigned int var0 = 0;
    while (1)
    {
        var0 = GetSysTime();
        if ( var0>2000 )
        {
            SetSysTime();
            SetRGB(0xFF00, 0xFF00, 0xFF00, 0xFF00, 0xFF00);
        }
        else
        {
            if ( var0>1000 )
            {
                SetRGB(0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000, 0xFF0000);
            }
        }
    }
    while(1);
}

