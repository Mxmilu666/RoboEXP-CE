#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <SetDisplayString.h>
#include <SetRFPassWord.h>
#include <GetRFModuleRemoteCode.h>
#include <SetDisplayVar.h>

int main(void)
{
    E2RCU_Init();
    unsigned long var1 = 0;
    SetLCDBack(ON);
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "Remote Code", YELLOW, BLACK);
    SetRFPassWord(_P1_, 1234567);
    while (1)
    {
        var1 = GetRFModuleRemoteCode(_P1_);
        SetDisplayVar(2, var1, YELLOW, BLACK);
    }
    return 1;
}

