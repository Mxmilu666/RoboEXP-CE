#ifndef _LED_
#define _LED_ unsigned long
#endif
#ifndef _LED_1_
#define _LED_1_ 288
#endif
