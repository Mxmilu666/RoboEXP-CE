#include "HardwareInfo.c"
#include "JMLib.c"
#include <GetSht30.h>
#include <SetDisplayString.h>
#include <SetDisplayFloat.h>

int main(void)
{
    C6RCU_Init();
    double var0 = 0;
    double var1 = 0;
    while (1)
    {
        var0 = GetSht30(_P1_, 0);
        var1 = GetSht30(_P1_, 1);
        SetDisplayString(4, "�¶�", YELLOW, BLACK);
        SetDisplayString(2, "ʪ��", YELLOW, BLACK);
        SetDisplayFloat(5, var0, YELLOW, BLACK);
        SetDisplayFloat(3, var1, YELLOW, BLACK);
    }
    while(1);
}

