#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <SetLCDBack.h>
#include <GetVolume.h>
#include <SetDisplayVar.h>
#include <SetWaitForTime.h>

int main(void)
{
    E2RCU_Init();
    int var0 = 0;
    SetDisplayString(1, "P1", YELLOW, BLACK);
    SetDisplayString(2, "MIC", YELLOW, BLACK);
    SetLCDBack(ON);
    while (1)
    {
        var0 = GetVolume(_P1_);
        SetDisplayVar(2, var0, YELLOW, BLACK);
        SetWaitForTime(0.1);
    }
    while(1);
}

