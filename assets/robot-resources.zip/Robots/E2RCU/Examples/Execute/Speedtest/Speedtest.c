#include "HardwareInfo.c"
#include <SetMotor.h>
#include <SetLCDBack.h>
#include <SetLCD16Char.h>
#include <GetADScable.h>
#include <SetSysTime.h>
#include <GetSysTime.h>
#include <SetLCD8Char.h>

int main(void)
{
    unsigned char value = 0;
    unsigned long time = 0;
    unsigned char cnt = 1;
    unsigned long speed = 0;
    SetMotor(_MOTOR_1_, 0, 100);
    SetMotor(_MOTOR_2_, 0, 100);
    SetLCDBack(1);
    SetLCD16Char('-', '-', '-', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
    while (1)
    {
        value = GetADScable(_SCABLEAD_1_);
        if ( (value>25)&&(cnt==1) )
        {
            time=0;
            cnt=2;
            SetSysTime(0);
        }
        if ( (value<25)&&(cnt==2) )
        {
            cnt=3;
        }
        if ( (value>25)&&(cnt==3) )
        {
            time = GetSysTime();
            cnt=1;
            speed=6000/time;
            if ( (speed>0)&&(speed<2000) )
            {
                SetLCD8Char(speed, 0, 0);
            }
        }
    }
    return 1;
}

