#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetMotorServo.h>
#include <SetWaitForTime.h>

int main(void)
{
   C1RCU_Init();
    long var0 = 0;
    while (1)
    {
        SetMotorServo(_S1_, 0);
        SetMotorServo(_S2_, 0);
        SetWaitForTime(1);
        SetMotorServo(_S1_, 1);
        SetMotorServo(_S2_, 90);
        SetWaitForTime(1);
    }
    while(1);
}

