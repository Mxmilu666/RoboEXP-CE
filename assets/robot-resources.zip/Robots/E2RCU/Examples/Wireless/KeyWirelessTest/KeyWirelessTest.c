#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDString.h>
#include <SetLCDBack.h>
#include <GetKeyWireless.h>
#include <SetLCD5Char.h>

int main(void)
{
    X2RCU_Init();
    unsigned int var0 = 0;
    SetLCDString(0, 0, "Key Test", YELLOW, BLACK);
    SetLCDBack(1);
    while (1)
    {
        var0 = GetKeyWireless(_WIRELESS_1_, "1234567");
        if ( var0!=888&&var0!=999 )
        {
            SetLCD5Char(80, 0, var0, YELLOW, BLACK);
        }
    }
    return 1;
}

