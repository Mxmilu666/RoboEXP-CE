#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetLCDBack.h>
#include <GetPS2Button.h>
#include <SetLCD3Char.h>
#include <SetTenthS.h>

int main(void)
{
    X1RCU_Init();
    unsigned int botton = 0;
    unsigned char bottonA = 0;
    unsigned char bottonB = 0;
    SetLCDBack(1);
    while (1)
    {
        botton = GetPS2Button(_PS2_1_);
        bottonA=botton/256;
        bottonB=botton%256;
        SetLCD3Char(0, 0, bottonA);
        SetLCD3Char(64, 0, bottonB);
        SetTenthS(3);
    }
    return 1;
}

