#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <GetLightSensor.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    unsigned int var0 = 0;
    unsigned int var1 = 0;
    long var2 = 0;
    long var3 = 0;
    SetDisplayString(1, "�����", YELLOW, BLACK);
    while (1)
    {
        var0 = GetLightSensor(_P1_);
        var1 = GetLightSensor(_P2_);
        var2 = GetLightSensor(_P3_);
        var3 = GetLightSensor(_P4_);
        SetDisplayVar(1, var0, YELLOW, BLACK);
        SetDisplayVar(2, var1, YELLOW, BLACK);
        SetDisplayVar(3, var2, YELLOW, BLACK);
        SetDisplayVar(4, var3, YELLOW, BLACK);
    }
    while(1);
}

