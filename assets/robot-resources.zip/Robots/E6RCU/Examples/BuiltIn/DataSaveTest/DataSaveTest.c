#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetData.h>
#include <GetData.h>
#include <SetDisplayVar.h>

int main(void)
{
    E6RCU_Init();
    unsigned int var0 = 0;
    long var1 = 0;
    SetData(1, 1);
    SetData(2, 2);
    var0 = GetData(1);
    var1 = GetData(2);
    SetDisplayVar(1, var0, YELLOW, BLACK);
    SetDisplayVar(2, var1, YELLOW, BLACK);
    while(1);
}

