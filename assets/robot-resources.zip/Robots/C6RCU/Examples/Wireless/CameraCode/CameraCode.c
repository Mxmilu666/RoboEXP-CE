#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <GetWifiCamCtrlData.h>
#include <SetDisplayVar.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    long var1 = 0;
    long var2 = 0;
    long var3 = 0;
    SetDisplayString(1, "X����", YELLOW, BLACK);
    SetDisplayString(2, "Y����", YELLOW, BLACK);
    SetDisplayString(3, "����ͷID", YELLOW, BLACK);
    SetDisplayString(4, "��ά���С", YELLOW, BLACK);
    while (1)
    {
        var0 = GetWifiCamCtrlData(1);
        var1 = GetWifiCamCtrlData(2);
        var2 = GetWifiCamCtrlData(3);
        var3 = GetWifiCamCtrlData(4);
        SetDisplayVar(1, var0, YELLOW, BLACK);
        SetDisplayVar(2, var1, YELLOW, BLACK);
        SetDisplayVar(3, var2, YELLOW, BLACK);
        SetDisplayVar(4, var3, YELLOW, BLACK);
    }
    while(1);
}

