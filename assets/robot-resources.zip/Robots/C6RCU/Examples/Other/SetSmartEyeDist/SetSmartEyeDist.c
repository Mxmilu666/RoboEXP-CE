#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetDisplayString.h>
#include <GetSmartEyeDist.h>
#include <SetSmartEyeAllLed2.h>

int main(void)
{
    C6RCU_Init();
    long var0 = 0;
    SetDisplayString(1, "�ǻ��۲ʵƲ���", YELLOW, BLACK);
    while (1)
    {
        var0 = GetSmartEyeDist(_P1_);
        if ( var0==1 )
        {
            SetSmartEyeAllLed2(_P1_, "100000000", "100000000", "100000000", "100000000", "100000000", "100000000", "100000000", "100000000");
        }
        else
        {
            SetSmartEyeAllLed2(_P1_, "100100100", "100100100", "100100100", "100100100", "100100100", "100100100", "100100100", "100100100");
        }
    }
    while(1);
}

