#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetServo.h>
#include <SetTenthS.h>
#include <SetNS.h>

int main(void)
{
    X1RCU_Init();
    while (1)
    {
        SetServo(_SERVO_1_, 35);
        SetTenthS(6);
        SetServo(_SERVO_1_, 90);
        SetNS(1);
        SetServo(_SERVO_1_, 145);
        SetTenthS(6);
    }
    return 1;
}

